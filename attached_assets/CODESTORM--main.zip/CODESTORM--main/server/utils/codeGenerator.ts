import fs from "fs";
import path from "path";
import { storage } from "../storage";

// Utility to create project files based on AI-generated code
export async function createProjectFiles(projectId: number, files: any[]) {
  try {
    // Validate input
    if (!projectId || !Array.isArray(files) || files.length === 0) {
      throw new Error("Invalid input for file creation");
    }
    
    // Process each file
    const createdFiles = await Promise.all(files.map(async (file) => {
      if (!file.path || !file.content) {
        throw new Error("File is missing path or content");
      }
      
      // Determine language based on file extension
      const extension = path.extname(file.path).replace(".", "");
      const language = determineLanguage(extension);
      
      // Store file in memory storage
      return await storage.createFile({
        project_id: projectId,
        path: file.path,
        content: file.content,
        language,
      });
    }));
    
    return createdFiles;
  } catch (error) {
    console.error("Error creating project files:", error);
    throw new Error(`Failed to create project files: ${error.message}`);
  }
}

// Determine the programming language based on file extension
function determineLanguage(extension: string): string {
  const languageMap: Record<string, string> = {
    js: "javascript",
    ts: "typescript",
    jsx: "javascript",
    tsx: "typescript",
    py: "python",
    java: "java",
    html: "html",
    css: "css",
    scss: "scss",
    json: "json",
    md: "markdown",
    sql: "sql",
    go: "go",
    rb: "ruby",
    php: "php",
    rs: "rust",
    c: "c",
    cpp: "cpp",
    cs: "csharp",
    swift: "swift",
    kt: "kotlin",
    sh: "shell",
    yml: "yaml",
    yaml: "yaml",
    xml: "xml",
    // Add more mappings as needed
  };
  
  return languageMap[extension.toLowerCase()] || "plaintext";
}

// Generate terminal commands based on project type
export function generateTerminalCommands(projectSpec: any): string[] {
  const commands: string[] = [];
  
  // Initial commands
  commands.push(`mkdir ${projectSpec.name || 'project'}`);
  commands.push(`cd ${projectSpec.name || 'project'}`);
  
  // Frontend setup
  if (projectSpec.frontend === "react") {
    commands.push("npx create-react-app client");
  } else if (projectSpec.frontend === "vue") {
    commands.push("npm create vue@latest client");
  } else if (projectSpec.frontend === "angular") {
    commands.push("ng new client");
  }
  
  // Backend setup
  if (projectSpec.backend === "nodejs" || projectSpec.backend === "express") {
    commands.push("mkdir server");
    commands.push("cd server");
    commands.push("npm init -y");
    commands.push("npm install express cors dotenv");
    if (projectSpec.database === "mongodb") {
      commands.push("npm install mongoose");
    } else if (projectSpec.database === "postgres") {
      commands.push("npm install pg");
    }
    commands.push("cd ..");
  } else if (projectSpec.backend === "python" || projectSpec.backend === "flask") {
    commands.push("mkdir server");
    commands.push("cd server");
    commands.push("python -m venv env");
    commands.push("pip install flask");
    if (projectSpec.database === "mongodb") {
      commands.push("pip install pymongo");
    } else if (projectSpec.database === "postgres") {
      commands.push("pip install psycopg2-binary");
    }
    commands.push("cd ..");
  }
  
  return commands;
}
