import { drizzle } from "drizzle-orm/postgres-js";
import { migrate } from "drizzle-orm/postgres-js/migrator";
import postgres from "postgres";
import * as schema from "../shared/schema";

// Script para migrar la base de datos
async function main() {
  console.log("Iniciando migración de la base de datos...");
  
  const connectionString = process.env.DATABASE_URL!;
  console.log("Conectando a la base de datos...");
  
  const client = postgres(connectionString);
  const db = drizzle(client);
  
  console.log("Ejecutando push de esquema...");
  
  try {
    // Crear las tablas basadas en el esquema
    for (const table of Object.values(schema)) {
      if (typeof table === 'object' && 'name' in table) {
        console.log(`Procesando tabla: ${table.name}`);
      }
    }
    
    // Utilizar la función push para migrar el esquema
    await db.execute(/* sql */ `
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        email TEXT,
        preferences JSONB,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS projects (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        user_id INTEGER NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS code_files (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        path TEXT NOT NULL,
        content TEXT,
        project_id INTEGER NOT NULL,
        language TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS ai_assistance (
        id SERIAL PRIMARY KEY,
        prompt TEXT NOT NULL,
        response TEXT NOT NULL,
        code_context TEXT,
        user_id INTEGER NOT NULL,
        model_used TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS conversations (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        user_id INTEGER NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS messages (
        id SERIAL PRIMARY KEY,
        conversation_id INTEGER NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        code TEXT,
        language TEXT,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS uploaded_files (
        id SERIAL PRIMARY KEY,
        filename TEXT NOT NULL,
        content TEXT NOT NULL,
        user_id INTEGER NOT NULL,
        conversation_id INTEGER,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS terminal_commands (
        id SERIAL PRIMARY KEY,
        command TEXT NOT NULL,
        output TEXT,
        user_id INTEGER NOT NULL,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    
    console.log("Migración completada con éxito!");
  } catch (error) {
    console.error("Error durante la migración:", error);
    process.exit(1);
  } finally {
    console.log("Cerrando conexión...");
    await client.end();
  }
}

main();