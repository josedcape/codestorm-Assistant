import { 
<<<<<<< HEAD
  users, type User, type InsertUser,
  conversations, type Conversation, type InsertConversation,
  messages, type Message, type InsertMessage,
  uploadedFiles, type UploadedFile, type InsertUploadedFile,
  terminalCommands, type TerminalCommand, type InsertTerminalCommand,
  aiAssistance, type AiAssistance, type InsertAiAssistance
} from "@shared/schema";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { eq } from "drizzle-orm";

// Función de utilidad para convertir valores undefined a null
function nullifyUndefined<T>(obj: T): T {
  if (obj === null || obj === undefined) {
    return obj;
  }
  
  if (typeof obj !== 'object') {
    return obj;
  }
  
  const result = { ...obj } as any;
  
  for (const key in result) {
    if (result[key] === undefined) {
      result[key] = null;
    } else if (typeof result[key] === 'object' && result[key] !== null) {
      result[key] = nullifyUndefined(result[key]);
    }
  }
  
  return result;
};

// PostgreSQL client setup
const connectionString = process.env.DATABASE_URL!;
const client = postgres(connectionString);
const db = drizzle(client);

// Storage interface with all CRUD methods needed for the application
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Conversation methods
  getConversations(userId: number): Promise<Conversation[]>;
  getConversation(id: number): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversation(id: number, title: string): Promise<Conversation | undefined>;
  deleteConversation(id: number): Promise<boolean>;

  // Message methods
  getMessages(conversationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // File methods
  getUploadedFiles(userId: number): Promise<UploadedFile[]>;
  getUploadedFile(id: number): Promise<UploadedFile | undefined>;
  createUploadedFile(file: InsertUploadedFile): Promise<UploadedFile>;
  deleteUploadedFile(id: number): Promise<boolean>;
  
  // Terminal methods
  getTerminalCommands(userId: number): Promise<TerminalCommand[]>;
  createTerminalCommand(command: InsertTerminalCommand): Promise<TerminalCommand>;
  
  // AI Assistance methods
  getAiAssistanceHistory(userId: number): Promise<AiAssistance[]>;
  createAiAssistance(assistance: InsertAiAssistance): Promise<AiAssistance>;
}

// PostgreSQL implementation of the Storage interface
export class PostgresStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const sanitizedUser = nullifyUndefined(user);
    const result = await db.insert(users).values(sanitizedUser).returning();
    return result[0];
  }

  // Conversation methods
  async getConversations(userId: number): Promise<Conversation[]> {
    return await db.select().from(conversations).where(eq(conversations.userId, userId));
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    const result = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
    return result[0];
  }

  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const sanitizedConversation = nullifyUndefined(conversation);
    const result = await db.insert(conversations).values(sanitizedConversation).returning();
    return result[0];
  }

  async updateConversation(id: number, title: string): Promise<Conversation | undefined> {
    const result = await db.update(conversations)
      .set({ title, updatedAt: new Date() })
      .where(eq(conversations.id, id))
      .returning();
    return result[0];
  }

  async deleteConversation(id: number): Promise<boolean> {
    const result = await db.delete(conversations).where(eq(conversations.id, id)).returning();
    return result.length > 0;
  }

  // Message methods
  async getMessages(conversationId: number): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.conversationId, conversationId));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const sanitizedMessage = nullifyUndefined(message);
    const result = await db.insert(messages).values(sanitizedMessage).returning();
    return result[0];
  }

  // File methods
  async getUploadedFiles(userId: number): Promise<UploadedFile[]> {
    return await db.select().from(uploadedFiles).where(eq(uploadedFiles.userId, userId));
  }

  async getUploadedFile(id: number): Promise<UploadedFile | undefined> {
    const result = await db.select().from(uploadedFiles).where(eq(uploadedFiles.id, id)).limit(1);
    return result[0];
  }

  async createUploadedFile(file: InsertUploadedFile): Promise<UploadedFile> {
    const sanitizedFile = nullifyUndefined(file);
    const result = await db.insert(uploadedFiles).values(sanitizedFile).returning();
    return result[0];
  }

  async deleteUploadedFile(id: number): Promise<boolean> {
    const result = await db.delete(uploadedFiles).where(eq(uploadedFiles.id, id)).returning();
    return result.length > 0;
  }

  // Terminal methods
  async getTerminalCommands(userId: number): Promise<TerminalCommand[]> {
    return await db.select().from(terminalCommands).where(eq(terminalCommands.userId, userId));
  }

  async createTerminalCommand(command: InsertTerminalCommand): Promise<TerminalCommand> {
    const sanitizedCommand = nullifyUndefined(command);
    const result = await db.insert(terminalCommands).values(sanitizedCommand).returning();
    return result[0];
  }

  // AI Assistance methods
  async getAiAssistanceHistory(userId: number): Promise<AiAssistance[]> {
    return await db.select().from(aiAssistance).where(eq(aiAssistance.userId, userId));
  }

  async createAiAssistance(assistance: InsertAiAssistance): Promise<AiAssistance> {
    const sanitizedAssistance = nullifyUndefined(assistance);
    const result = await db.insert(aiAssistance).values(sanitizedAssistance).returning();
    return result[0];
  }
}

// For backward compatibility, also provide a memory-based implementation
export class MemStorage implements IStorage {
  private users = new Map<number, User>();
  private conversations = new Map<number, Conversation>();
  private messages = new Map<number, Message[]>();
  private uploadedFiles = new Map<number, UploadedFile>();
  private terminalCommands = new Map<number, TerminalCommand[]>();
  private aiAssistanceHistory = new Map<number, AiAssistance[]>();
  
  private currentIds = {
    users: 1,
    conversations: 1,
    messages: 1,
    uploadedFiles: 1,
    terminalCommands: 1,
    aiAssistance: 1,
  };

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentIds.users++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: now,
      email: insertUser.email || null,
      preferences: insertUser.preferences || null
    };
    this.users.set(id, user);
    return user;
  }

  // Conversation methods
  async getConversations(userId: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(
      (conv) => conv.userId === userId
    );
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const id = this.currentIds.conversations++;
    const now = new Date();
    const newConversation: Conversation = {
      ...conversation,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.conversations.set(id, newConversation);
    return newConversation;
  }

  async updateConversation(id: number, title: string): Promise<Conversation | undefined> {
    const conversation = this.conversations.get(id);
    if (!conversation) return undefined;
    
    const updatedConversation = {
      ...conversation,
      title,
      updatedAt: new Date()
    };
    this.conversations.set(id, updatedConversation);
    return updatedConversation;
  }

  async deleteConversation(id: number): Promise<boolean> {
    return this.conversations.delete(id);
  }

  // Message methods
  async getMessages(conversationId: number): Promise<Message[]> {
    return this.messages.get(conversationId) || [];
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.currentIds.messages++;
    const now = new Date();
    const newMessage: Message = {
      ...message,
      id,
      timestamp: now,
      code: message.code || null,
      language: message.language || null
    };
    
    const messages = this.messages.get(message.conversationId) || [];
    messages.push(newMessage);
    this.messages.set(message.conversationId, messages);
    
=======
  type Project, type InsertProject, 
  type Message, type InsertMessage,
  type File, type InsertFile,
  type Settings, type InsertSettings,
  type ModelProvider,
  projects, messages, files, settings
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";
import dotenv from 'dotenv';

// Aseguramos que las variables de entorno estén cargadas
dotenv.config();

// Expanded storage interface for CODESTORM AI
export interface IStorage {
  // Project CRUD
  getProject(id: number): Promise<Project | undefined>;
  getProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;

  // Message CRUD
  getMessages(projectId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;

  // File CRUD
  getFiles(projectId: number): Promise<File[]>;
  getFile(id: number): Promise<File | undefined>;
  createFile(file: InsertFile): Promise<File>;
  updateFile(id: number, content: string): Promise<File | undefined>;
  deleteFile(id: number): Promise<boolean>;

  // Settings
  getSettings(): Promise<Settings | undefined>;
  updateSettings(settings: Partial<InsertSettings>): Promise<Settings>;
}

export class DatabaseStorage implements IStorage {
  // Project methods
  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.created_at));
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined> {
    const [updatedProject] = await db.update(projects)
      .set(project)
      .where(eq(projects.id, id))
      .returning();
    return updatedProject;
  }

  async deleteProject(id: number): Promise<boolean> {
    const result = await db.delete(projects).where(eq(projects.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Message methods
  async getMessages(projectId: number): Promise<Message[]> {
    return await db.select()
      .from(messages)
      .where(eq(messages.project_id, projectId))
      .orderBy(messages.timestamp);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
>>>>>>> 132aeba36e2ea9de048066f0f5011c34e421d7d7
    return newMessage;
  }

  // File methods
<<<<<<< HEAD
  async getUploadedFiles(userId: number): Promise<UploadedFile[]> {
    return Array.from(this.uploadedFiles.values()).filter(
      (file) => file.userId === userId
    );
  }

  async getUploadedFile(id: number): Promise<UploadedFile | undefined> {
    return this.uploadedFiles.get(id);
  }

  async createUploadedFile(file: InsertUploadedFile): Promise<UploadedFile> {
    const id = this.currentIds.uploadedFiles++;
    const now = new Date();
    const newFile: UploadedFile = {
      ...file,
      id,
      timestamp: now,
      conversationId: file.conversationId || null
    };
    this.uploadedFiles.set(id, newFile);
    return newFile;
  }

  async deleteUploadedFile(id: number): Promise<boolean> {
    return this.uploadedFiles.delete(id);
  }

  // Terminal methods
  async getTerminalCommands(userId: number): Promise<TerminalCommand[]> {
    return this.terminalCommands.get(userId) || [];
  }

  async createTerminalCommand(command: InsertTerminalCommand): Promise<TerminalCommand> {
    const id = this.currentIds.terminalCommands++;
    const now = new Date();
    const newCommand: TerminalCommand = {
      ...command,
      id,
      timestamp: now,
      output: command.output || null
    };
    
    const commands = this.terminalCommands.get(command.userId) || [];
    commands.push(newCommand);
    this.terminalCommands.set(command.userId, commands);
    
    return newCommand;
  }

  // AI Assistance methods
  async getAiAssistanceHistory(userId: number): Promise<AiAssistance[]> {
    return this.aiAssistanceHistory.get(userId) || [];
  }

  async createAiAssistance(assistance: InsertAiAssistance): Promise<AiAssistance> {
    const id = this.currentIds.aiAssistance++;
    const now = new Date();
    const newAssistance: AiAssistance = {
      ...assistance,
      id,
      createdAt: now,
      codeContext: assistance.codeContext || null
    };
    
    const history = this.aiAssistanceHistory.get(assistance.userId) || [];
    history.push(newAssistance);
    this.aiAssistanceHistory.set(assistance.userId, history);
    
    return newAssistance;
  }
}

// Use PostgreSQL storage since we have a database available
export const storage = new PostgresStorage();
=======
  async getFiles(projectId: number): Promise<File[]> {
    return await db.select()
      .from(files)
      .where(eq(files.project_id, projectId));
  }

  async getFile(id: number): Promise<File | undefined> {
    const [file] = await db.select().from(files).where(eq(files.id, id));
    return file;
  }

  async createFile(file: InsertFile): Promise<File> {
    const [newFile] = await db.insert(files).values(file).returning();
    return newFile;
  }

  async updateFile(id: number, content: string): Promise<File | undefined> {
    const [updatedFile] = await db.update(files)
      .set({ content })
      .where(eq(files.id, id))
      .returning();
    return updatedFile;
  }

  async deleteFile(id: number): Promise<boolean> {
    const result = await db.delete(files).where(eq(files.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Settings methods
  async getSettings(): Promise<Settings | undefined> {
    // We're using the first settings record by default
    const [setting] = await db.select().from(settings).limit(1);
    
    // If no settings exist, create a default one
    if (!setting) {
      return this.initializeDefaultSettings();
    }
    
    return setting;
  }

  async updateSettings(settingsData: Partial<InsertSettings>): Promise<Settings> {
    // First get the current settings
    let setting = await this.getSettings();
    
    // If no settings, create default one
    if (!setting) {
      setting = await this.initializeDefaultSettings();
    }
    
    // If we have api_keys in the update data, merge them with existing keys
    const apiKeys = settingsData.api_keys 
      ? { ...setting.api_keys, ...settingsData.api_keys }
      : setting.api_keys;
    
    // Update other fields
    const dataToUpdate = {
      ...settingsData,
      api_keys: apiKeys
    };
    
    // Update the settings
    const [updatedSettings] = await db.update(settings)
      .set(dataToUpdate)
      .where(eq(settings.id, setting.id))
      .returning();
    
    return updatedSettings;
  }
  
  private async initializeDefaultSettings(): Promise<Settings> {
    // Usar las claves API del archivo .env si están disponibles
    const defaultSettings: InsertSettings = {
      preferred_model: "openai",
      api_keys: {
        openai: process.env.OPENAI_API_KEY || "",
        anthropic: process.env.ANTHROPIC_API_KEY || "",
        gemini: process.env.GEMINI_API_KEY || ""
      }
    };
    
    console.log('Initializing settings with environment API keys');
    
    const [newSettings] = await db.insert(settings)
      .values(defaultSettings)
      .returning();
    
    return newSettings;
  }
}

// Export the storage instance
export const storage = new DatabaseStorage();
>>>>>>> 132aeba36e2ea9de048066f0f5011c34e421d7d7
