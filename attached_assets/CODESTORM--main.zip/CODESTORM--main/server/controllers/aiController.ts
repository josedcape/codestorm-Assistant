import { ModelProvider } from "@shared/schema";
import { storage } from "../storage";
import { processWithOpenAI } from "../ai/openai";
import { processWithAnthropic } from "../ai/anthropic";
import { processWithGemini } from "../ai/gemini";
import dotenv from 'dotenv';

// Aseguramos que las variables de entorno estén cargadas
dotenv.config();

// Main AI processing function - routes to the appropriate model
export async function processAiRequest(prompt: string, modelProvider: ModelProvider, attempts: number = 0) {
  // Avoid infinite recursion
  if (attempts > 2) {
    throw new Error("Maximum fallback attempts reached");
  }

  // Obtener las claves de API desde la base de datos o usar las variables de entorno como respaldo
  // Intentar obtener las claves de la base de datos primero
  const settings = await storage.getSettings();
  
  // Usar las claves de la base de datos si existen y no están vacías, o usar las variables de entorno como respaldo
  const openaiApiKey = (settings?.api_keys?.openai && settings.api_keys?.openai.length > 0) 
    ? settings.api_keys?.openai 
    : process.env.OPENAI_API_KEY;
    
  const anthropicApiKey = (settings?.api_keys?.anthropic && settings.api_keys?.anthropic.length > 0)
    ? settings.api_keys?.anthropic
    : process.env.ANTHROPIC_API_KEY;
    
  const geminiApiKey = (settings?.api_keys?.gemini && settings.api_keys?.gemini.length > 0)
    ? settings.api_keys?.gemini
    : process.env.GEMINI_API_KEY;

  // Basic validation for empty prompts
  if (!prompt || prompt.trim().length === 0) {
    throw new Error("Empty prompt provided");
  }
  
  // Check that at least one API key is available
  if (!openaiApiKey && !anthropicApiKey && !geminiApiKey) {
    throw new Error("No AI API keys found in environment variables");
  }
  
  // Timeout promise to prevent hanging
  const timeoutMs = 30000; // 30 seconds
  const timeoutPromise = new Promise((_, reject) => {
    setTimeout(() => reject(new Error(`Request timed out after ${timeoutMs}ms`)), timeoutMs);
  });
  
  try {
    // Process based on selected model with timeout
    let apiRequest;
    switch (modelProvider) {
      case "openai":
        if (!openaiApiKey) {
          console.warn("OpenAI API key not found, trying fallback provider");
          return processAiRequest(prompt, "anthropic", attempts + 1);
        }
        apiRequest = processWithOpenAI(prompt, openaiApiKey);
        break;
      case "anthropic":
        if (!anthropicApiKey) {
          console.warn("Anthropic API key not found, trying fallback provider");
          return processAiRequest(prompt, "openai", attempts + 1);
        }
        apiRequest = processWithAnthropic(prompt, anthropicApiKey);
        break;
      case "gemini":
        if (!geminiApiKey) {
          console.warn("Gemini API key not found, trying fallback provider");
          return processAiRequest(prompt, "openai", attempts + 1);
        }
        apiRequest = processWithGemini(prompt, geminiApiKey);
        break;
      default:
        throw new Error(`Unsupported model provider: ${modelProvider}`);
    }
    
    // Race the API request against timeout
    const result = await Promise.race([apiRequest, timeoutPromise]);
    return result;
    
  } catch (error: any) {
    console.error(`Error with ${modelProvider} API:`, error.message);
    
    // Determine fallback provider
    let fallbackProvider: ModelProvider;
    if (modelProvider === "openai") {
      fallbackProvider = anthropicApiKey ? "anthropic" : "gemini";
    } else if (modelProvider === "anthropic") {
      fallbackProvider = openaiApiKey ? "openai" : "gemini";
    } else {
      fallbackProvider = openaiApiKey ? "openai" : "anthropic";
    }
    
    // Check if fallback provider's API key exists
    const fallbackApiKey = 
      fallbackProvider === "openai" ? openaiApiKey :
      fallbackProvider === "anthropic" ? anthropicApiKey : 
      geminiApiKey;
    
    if (fallbackApiKey) {
      console.log(`Falling back to ${fallbackProvider} API`);
      return processAiRequest(prompt, fallbackProvider, attempts + 1);
    } else {
      throw new Error(`Error with ${modelProvider} API and no fallback available: ${error.message}`);
    }
  }
}

// Analyze user requirements to extract project specs
export async function analyzeRequirements(prompt: string, modelProvider: ModelProvider, attempts: number = 0) {
  // Prevent infinite recursion with fallbacks
  if (attempts > 2) {
    throw new Error("Maximum fallback attempts reached");
  }

  // Enhance the prompt to extract structured information with more precise instructions
  const analysisPrompt = `
    Analyze this project description and extract ONLY technical details.
    Return a JSON object with EXACTLY this structure (no additional fields):
    {
      "frontend": "technology name or null",
      "backend": "technology name or null",
      "database": "database type or null",
      "features": ["feature1", "feature2"],
      "authentication": boolean,
      "deployment": "deployment platform or null",
      "complexity": "simple|medium|complex"
    }

    IMPORTANT: Only include specific technologies mentioned in the description.
    If a technology is not specified, use null. Be concise with feature names.

    Project description: ${prompt}
  `;
  
  // Set timeout for analysis request
  const timeoutPromise = new Promise((_, reject) => {
    setTimeout(() => reject(new Error("Analysis request timed out after 8 seconds")), 8000);
  });
  
  try {
    // Race the AI request against the timeout
    const result = await Promise.race([
      processAiRequest(analysisPrompt, modelProvider),
      timeoutPromise
    ]);
    
    // Parse the response, assuming it's in JSON format
    try {
      // Handle different response formats from different models
      let jsonResponse;
      if (typeof result === 'string') {
        // Extract JSON from string if needed
        const jsonMatch = result.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          jsonResponse = JSON.parse(jsonMatch[0]);
        } else {
          console.warn("Could not extract JSON from response, trying fallback model");
          // Try another model provider
          const fallbackProvider = modelProvider === 'openai' ? 'anthropic' : 'openai';
          console.log(`Falling back to ${fallbackProvider} for analysis`);
          return analyzeRequirements(prompt, fallbackProvider as ModelProvider, attempts + 1);
        }
      } else if (typeof result === 'object') {
        jsonResponse = result;
      } else {
        throw new Error("Unexpected response format");
      }
      
      // Validate the structure of the response
      const requiredFields = ['frontend', 'backend', 'database', 'features', 'authentication', 'complexity'];
      const missingFields = requiredFields.filter(field => !Object.prototype.hasOwnProperty.call(jsonResponse, field));
      
      if (missingFields.length > 0) {
        console.warn(`Response missing required fields: ${missingFields.join(', ')}. Trying fallback.`);
        // Try another model provider
        const fallbackProvider = modelProvider === 'openai' ? 'anthropic' : 'openai';
        return analyzeRequirements(prompt, fallbackProvider as ModelProvider, attempts + 1);
      }
      
      // Ensure features is an array
      if (!Array.isArray(jsonResponse.features)) {
        jsonResponse.features = jsonResponse.features ? [jsonResponse.features] : [];
      }
      
      // Ensure authentication is a boolean
      if (typeof jsonResponse.authentication !== 'boolean') {
        jsonResponse.authentication = jsonResponse.authentication === 'true' || 
                                   jsonResponse.authentication === true || 
                                   jsonResponse.authentication === 'yes';
      }
      
      return {
        analysisResult: jsonResponse,
        rawResponse: result
      };
    } catch (error: any) {
      console.error("Error parsing AI response:", error);
      
      // Try fallback provider if parsing fails
      if (error.message.includes("JSON") || error.message.includes("parse")) {
        const fallbackProvider = modelProvider === 'openai' ? 'anthropic' : 'openai';
        console.log(`Trying ${fallbackProvider} due to parsing error`);
        return analyzeRequirements(prompt, fallbackProvider as ModelProvider, attempts + 1);
      }
      
      throw new Error(`Failed to parse AI analysis response: ${error.message}`);
    }
  } catch (error: any) {
    console.error("Error in analyzeRequirements:", error);
    
    // Check if it's a timeout error and try with a different provider
    if (error.message.includes("timed out")) {
      const fallbackProvider = modelProvider === 'openai' ? 'anthropic' : 
                             (modelProvider === 'anthropic' ? 'gemini' : 'openai');
      console.log(`Analysis timed out, trying ${fallbackProvider}`);
      return analyzeRequirements(prompt, fallbackProvider as ModelProvider, attempts + 1);
    }
    
    throw new Error(`Error analyzing requirements: ${error.message}`);
  }
}

// Generate code based on project specifications
export async function generateCode(specs: any, modelProvider: ModelProvider) {
  // Create a structured prompt for code generation with clear constraints
  const generationPrompt = `
    Generate starter code for a project with the following specifications:
    ${JSON.stringify(specs, null, 2)}
    
    IMPORTANT GUIDELINES:
    1. Generate minimal, essential files only - focus on core functionality
    2. Keep file content concise (max 150 lines per file)
    3. Prioritize structure over completeness
    4. Focus on critical files (main components, routes, models)
    
    Provide code files in this exact JSON format:
    {
      "files": [
        {
          "path": "relative/path/to/file.ext",
          "content": "// file content here",
          "language": "programming language"
        }
      ],
      "instructions": "Brief setup instructions"
    }
  `;
  
  // Set timeout to prevent hanging
  const timeoutPromise = new Promise((_, reject) => {
    setTimeout(() => reject(new Error("AI request timed out after 15 seconds")), 15000);
  });
  
  try {
    // Race the AI request against the timeout
    const result = await Promise.race([
      processAiRequest(generationPrompt, modelProvider),
      timeoutPromise
    ]) as string;
    
    // Parse the response, assuming it returns structured file data
    try {
      // Handle different response formats from different models
      let codeFiles;
      if (typeof result === 'string') {
        // Extract JSON from string if needed
        const jsonMatch = result.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          codeFiles = JSON.parse(jsonMatch[0]);
        } else {
          console.warn("Could not extract JSON from response, trying fallback model");
          // Try with a different model provider
          const fallbackProvider = modelProvider === 'openai' ? 'anthropic' : 'openai';
          console.log(`Falling back to ${fallbackProvider} for code generation`);
          
          // Recursive call with fallback provider and simplified specs
          return generateCode({
            ...specs,
            complexity: "minimal" // Simplify for fallback
          }, fallbackProvider as ModelProvider);
        }
      } else if (typeof result === 'object') {
        codeFiles = result;
      } else {
        throw new Error("Unexpected response format");
      }
      
      // Validate response structure
      if (!codeFiles.files || !Array.isArray(codeFiles.files) || codeFiles.files.length === 0) {
        throw new Error("Invalid response structure: missing files array");
      }
      
      return {
        generatedFiles: codeFiles.files || [],
        instructions: codeFiles.instructions || "",
        rawResponse: result
      };
    } catch (error: any) {
      console.error("Error parsing AI response:", error);
      
      // Try fallback provider if parsing fails
      if (error.message.includes("JSON")) {
        const fallbackProvider = modelProvider === 'openai' ? 'anthropic' : 'openai';
        console.log(`Trying ${fallbackProvider} due to parsing error`);
        return generateCode(specs, fallbackProvider as ModelProvider);
      }
      
      throw new Error(`Failed to parse AI code generation response: ${error.message}`);
    }
  } catch (error: any) {
    console.error("Error in generateCode:", error);
    
    // Check if it's a timeout error and try with a different provider
    if (error.message.includes("timed out")) {
      const fallbackProvider = modelProvider === 'openai' ? 'anthropic' : 
                              (modelProvider === 'anthropic' ? 'gemini' : 'openai');
      console.log(`Request timed out, trying ${fallbackProvider}`);
      
      // Simplify specs for fallback
      const simplifiedSpecs = {
        ...specs,
        features: specs.features?.slice(0, 2) || [], // Limit features
        complexity: "minimal"
      };
      
      return generateCode(simplifiedSpecs, fallbackProvider as ModelProvider);
    }
    
    throw new Error(`Error generating code: ${error.message}`);
  }
}
