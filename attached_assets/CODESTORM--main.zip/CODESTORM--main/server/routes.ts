<<<<<<< HEAD
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import fs from "fs";
import path from "path";
import { exec } from "child_process";
import util from "util";
import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";
import { File, Folder, insertConversationSchema, insertMessageSchema, insertUploadedFileSchema, insertTerminalCommandSchema, insertAiAssistanceSchema } from "@shared/schema";

const execPromise = util.promisify(exec);

// Inicializar OpenAI con la clave API
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "mock-key",
});

// Inicializar Anthropic con la clave API
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || "mock-key",
});

// Simulate a file system for development purposes
const rootDir = process.cwd();
const projectFiles: Record<string, string> = {};
const projectFolders: Set<string> = new Set(["/src", "/public"]);

// Initialize with some basic files
projectFiles["/src/app.js"] = `// Main application file
import { fetchData, processResults } from './utils.js';
import { apiClient } from './api.js';

class App {
  constructor() {
    this.data = [];
    this.isLoading = false;
    this.error = null;
  }

  async initialize() {
    try {
      this.isLoading = true;
      const response = await fetchData('/api/resources');
      this.data = processResults(response);
    } catch (err) {
      this.error = err.message;
      console.error('Failed to initialize:', err);
    } finally {
      this.isLoading = false;
    }
  }
}`;

projectFiles["/src/utils.js"] = `// Utility functions

export function fetchData(url, options = {}) {
  return fetch(url, options)
    .then(response => {
      if (!response.ok) {
        throw new Error(\`HTTP error! status: \${response.status}\`);
      }
      return response.json();
    });
}

export function processResults(data) {
  // Transform the data as needed
  return Array.isArray(data) ? data.map(item => ({
    ...item,
    processedAt: new Date().toISOString()
  })) : [];
}`;

projectFiles["/src/api.js"] = `// API client

export const apiClient = {
  async get(endpoint) {
    return fetch(endpoint)
      .then(response => response.json());
  },
  
  async post(endpoint, data) {
    return fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    }).then(response => response.json());
  }
};`;

export async function registerRoutes(app: Express): Promise<Server> {
  // File system APIs
  app.get("/api/files", async (req, res) => {
    try {
      const requestedPath = (req.query.path as string) || "/";
      
      // Get the list of files and folders
      // In a real implementation, this would read from the actual file system
      const files: File[] = [];
      const folders: Folder[] = [];
      
      // Add files
      Object.keys(projectFiles).forEach(filePath => {
        const dirName = path.dirname(filePath);
        if (dirName === requestedPath || requestedPath === "/") {
          files.push({
            path: filePath,
            name: path.basename(filePath)
          });
        }
      });
      
      // Add folders
      projectFolders.forEach(folderPath => {
        const dirName = path.dirname(folderPath);
        if (dirName === requestedPath || requestedPath === "/") {
          folders.push({
            path: folderPath,
            name: path.basename(folderPath)
          });
        }
      });
      
      res.json({ files, folders });
    } catch (error) {
      console.error("Error listing files:", error);
      res.status(500).json({ error: "Failed to list files" });
    }
  });

  app.get("/api/files/:path(*)", (req, res) => {
    try {
      const filePath = "/" + req.params.path;
      
      if (projectFiles[filePath]) {
        res.send(projectFiles[filePath]);
      } else {
        res.status(404).json({ error: "File not found" });
      }
    } catch (error) {
      console.error("Error reading file:", error);
      res.status(500).json({ error: "Failed to read file" });
    }
  });

  app.put("/api/files/:path(*)", (req, res) => {
    try {
      const filePath = "/" + req.params.path;
      const { content } = req.body;
      
      if (typeof content !== 'string') {
        return res.status(400).json({ error: "Content must be a string" });
      }
      
      // Update the file
      projectFiles[filePath] = content;
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error writing file:", error);
      res.status(500).json({ error: "Failed to write file" });
    }
  });

  app.post("/api/files", (req, res) => {
    try {
      const { path: filePath, content } = req.body;
      
      if (!filePath) {
        return res.status(400).json({ error: "Path is required" });
      }
      
      const normalizedPath = filePath.startsWith("/") ? filePath : `/${filePath}`;
      
      if (projectFiles[normalizedPath]) {
        return res.status(400).json({ error: "File already exists" });
      }
      
      // Create the file
      projectFiles[normalizedPath] = content || "";
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error creating file:", error);
      res.status(500).json({ error: "Failed to create file" });
    }
  });

  app.post("/api/folders", (req, res) => {
    try {
      const { path: folderPath } = req.body;
      
      if (!folderPath) {
        return res.status(400).json({ error: "Path is required" });
      }
      
      const normalizedPath = folderPath.startsWith("/") ? folderPath : `/${folderPath}`;
      
      if (projectFolders.has(normalizedPath)) {
        return res.status(400).json({ error: "Folder already exists" });
      }
      
      // Create the folder
      projectFolders.add(normalizedPath);
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error creating folder:", error);
      res.status(500).json({ error: "Failed to create folder" });
    }
  });

  app.delete("/api/files/:path(*)", (req, res) => {
    try {
      const filePath = "/" + req.params.path;
      
      if (!projectFiles[filePath]) {
        return res.status(404).json({ error: "File not found" });
      }
      
      // Delete the file
      delete projectFiles[filePath];
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting file:", error);
      res.status(500).json({ error: "Failed to delete file" });
    }
  });

  app.delete("/api/folders/:path(*)", (req, res) => {
    try {
      const folderPath = "/" + req.params.path;
      
      if (!projectFolders.has(folderPath)) {
        return res.status(404).json({ error: "Folder not found" });
      }
      
      // Delete the folder and all files within it
      projectFolders.delete(folderPath);
      
      // Delete all files within the folder
      Object.keys(projectFiles).forEach(filePath => {
        if (filePath.startsWith(folderPath)) {
          delete projectFiles[filePath];
        }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting folder:", error);
      res.status(500).json({ error: "Failed to delete folder" });
    }
  });

  // Code execution API
  app.post("/api/execute", async (req, res) => {
    try {
      const { code, language, filename } = req.body;
      
      if (!code) {
        return res.status(400).json({ error: "Code is required" });
      }
      
      let executionResult;
      let error;
      
      // For JavaScript, we can use Node.js to execute
      if (language === "javascript") {
        try {
          // Create temporary file
          const tempDir = path.join(rootDir, "temp");
          if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir);
          }
          
          const tempFile = path.join(tempDir, filename || "script.js");
          fs.writeFileSync(tempFile, code);
          
          // Execute the file
          const { stdout, stderr } = await execPromise(`node ${tempFile}`);
          
          // Clean up
          fs.unlinkSync(tempFile);
          
          executionResult = {
            output: stdout,
            error: stderr || undefined,
            exitCode: 0
          };
        } catch (err: any) {
          const execError: any = err;
          executionResult = {
            output: "",
            error: execError.message || "Execution failed",
            exitCode: execError.code || 1
          };
        }
      } else {
        // For other languages, we might need different execution methods
        // This is a simplified example
        executionResult = {
          output: `Execution for ${language} not implemented yet`,
          exitCode: 1
        };
      }
      
      res.json(executionResult);
    } catch (error) {
      console.error("Error executing code:", error);
      res.status(500).json({ 
        output: "",
        error: "Server error during execution",
        exitCode: 1
      });
    }
  });

  // AI Assistant APIs
  app.post("/api/ai/generate", async (req, res) => {
    try {
      const { prompt, context, codeContext, model = "gpt-4o", apiKey } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }
      
      // Combine the context and prompt
      const fullPrompt = [
        context ? context : "You are a helpful coding assistant.",
        codeContext ? codeContext : "",
        prompt
      ].filter(Boolean).join("\n\n");
      
      // Verificar si hay una clave API proporcionada o usar la del environment
      const useApiKey = apiKey || process.env.OPENAI_API_KEY;
      
      if (!useApiKey || useApiKey === "mock-key") {
        // If no API key, return a mock response
        return res.json({
          text: "Sorry, I encountered an error while generating a response. Please check your API key is correctly set in the configuration panel (Settings > API Keys). You need to provide a valid API key for the selected model."
        });
      }
      
      try {
        let responseText = "";
        
        // Usar el modelo solicitado o el predeterminado
        if (model.includes('gpt') || model === 'gpt-4o') {
          // Configurar OpenAI con la clave proporcionada
          const tempOpenAI = new OpenAI({ apiKey: useApiKey });
          
          const completion = await tempOpenAI.chat.completions.create({
            model: "gpt-4o", // Usar gpt-4o como modelo predeterminado
            messages: [
              { role: "system", content: "You are a helpful coding assistant. Provide concise, accurate responses with code examples when appropriate." },
              { role: "user", content: fullPrompt }
            ],
            max_tokens: 1000,
          });
          
          responseText = completion.choices[0].message.content || "No response generated";
        } else {
          // Implementar manejo para otros modelos (Claude, Gemini, etc.)
          // Por ahora, usar simulación para otros modelos
          responseText = `Respuesta simulada del modelo ${model}. Para obtener respuestas reales, asegúrate de tener configurada la clave API correcta y que el backend soporte este modelo.`;
        }
        
        res.json({ text: responseText });
      } catch (aiError) {
        console.error("OpenAI API error:", aiError);
        res.json({ 
          text: "Sorry, I encountered an error while generating a response. Please check your API key and try again." 
        });
      }
    } catch (error) {
      console.error("Error in AI generate:", error);
      res.status(500).json({ error: "Failed to generate AI response" });
    }
  });

  app.post("/api/ai/code", async (req, res) => {
    try {
      const { code, language, prompt } = req.body;
      
      if (!code || !prompt) {
        return res.status(400).json({ error: "Code and prompt are required" });
      }
      
      if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "mock-key") {
        // If no API key, return a mock response
        return res.json({
          text: "This is a simulated code suggestion. To get real AI code suggestions, add your OpenAI API key as an environment variable named OPENAI_API_KEY."
        });
      }
      
      try {
        // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        const completion = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            { role: "system", content: "You are a code assistant that provides suggestions and improvements. When providing code, always use markdown code blocks with appropriate language syntax." },
            { 
              role: "user", 
              content: `I'm working with the following ${language} code:\n\n\`\`\`${language}\n${code}\n\`\`\`\n\nBased on this code, ${prompt}`
            }
          ],
          max_tokens: 1000,
        });
        
        const responseText = completion.choices[0].message.content || "No suggestion generated";
        
        res.json({ text: responseText });
      } catch (aiError) {
        console.error("OpenAI API error:", aiError);
        res.json({ 
          text: "Sorry, I encountered an error while generating code suggestions. Please check your API key and try again." 
        });
      }
    } catch (error) {
      console.error("Error in AI code suggestion:", error);
      res.status(500).json({ error: "Failed to generate code suggestion" });
    }
  });

  app.post("/api/ai/explain", async (req, res) => {
    try {
      const { code, language } = req.body;
      
      if (!code) {
        return res.status(400).json({ error: "Code is required" });
      }
      
      if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "mock-key") {
        // If no API key, return a mock response
        return res.json({
          text: "This is a simulated code explanation. To get real AI code explanations, add your OpenAI API key as an environment variable named OPENAI_API_KEY."
        });
      }
      
      try {
        // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        const completion = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            { role: "system", content: "You are a coding instructor that explains code in detail. Break down the code into smaller parts and explain the purpose of each part." },
            { 
              role: "user", 
              content: `Please explain this ${language} code:\n\n\`\`\`${language}\n${code}\n\`\`\``
            }
          ],
          max_tokens: 1000,
        });
        
        const responseText = completion.choices[0].message.content || "No explanation generated";
        
        res.json({ text: responseText });
      } catch (aiError) {
        console.error("OpenAI API error:", aiError);
        res.json({ 
          text: "Sorry, I encountered an error while generating an explanation. Please check your API key and try again." 
        });
      }
    } catch (error) {
      console.error("Error in AI explain:", error);
      res.status(500).json({ error: "Failed to generate explanation" });
    }
  });
  
  // Nueva ruta para corregir errores de código usando Anthropic
  app.post("/api/ai/fix", async (req, res) => {
    try {
      const { code, language, errorMessage } = req.body;
      
      if (!code) {
        return res.status(400).json({ error: "Code is required" });
      }
      
      // Verificar si tenemos API key de Anthropic
      if (!process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_API_KEY === "mock-key") {
        // Si no hay API key de Anthropic, usamos OpenAI como fallback
        if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "mock-key") {
          // Si no hay API key de ninguno, devolvemos respuesta simulada
          return res.json({
            text: "Esta es una respuesta simulada para corrección de código. Para obtener respuestas reales, añade una clave API de Anthropic o OpenAI como variable de entorno."
          });
        } else {
          try {
            // Usar OpenAI para la corrección
            // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            const userContent = errorMessage 
              ? `Por favor, corrige este código en ${language} que está generando el siguiente error: ${errorMessage}\n\n\`\`\`${language}\n${code}\n\`\`\``
              : `Por favor, revisa este código en ${language} y corrige cualquier problema o error que encuentres:\n\n\`\`\`${language}\n${code}\n\`\`\``;
              
            const completion = await openai.chat.completions.create({
              model: "gpt-4o",
              messages: [
                { role: "system", content: "Eres un asistente experto en programación que ayuda a corregir errores en el código. Proporciona soluciones claras y explica los problemas encontrados." },
                { role: "user", content: userContent }
              ],
              max_tokens: 1000,
            });
            
            const responseText = completion.choices[0].message.content || "No se pudo generar una corrección";
            
            return res.json({ text: responseText });
          } catch (openaiError) {
            console.error("OpenAI API error:", openaiError);
            return res.json({ 
              text: "Lo siento, encontré un error al generar una corrección con OpenAI. Por favor, verifica tu API key e intenta de nuevo." 
            });
          }
        }
      }
      
      try {
        // Usar Anthropic para la corrección
        // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
        const errorInfo = errorMessage ? `y estoy recibiendo este error: ${errorMessage}` : "";
        const anthropicMsg = await anthropic.messages.create({
          model: "claude-3-7-sonnet-20250219",
          max_tokens: 1000,
          system: "Eres un asistente experto en programación que ayuda a corregir errores en el código. Proporciona soluciones claras y explica los problemas encontrados.",
          messages: [
            {
              role: "user",
              content: `Por favor, corrige este código en ${language} ${errorInfo}:\n\n\`\`\`${language}\n${code}\n\`\`\`\n\nProporciona el código corregido en un bloque de código markdown y explica los problemas encontrados.`
            }
          ]
        });
        
        // Extraer el texto (manejando el tipo de forma segura)
        let responseText = "No se pudo generar una corrección";
        if (anthropicMsg.content && anthropicMsg.content.length > 0 && 'text' in anthropicMsg.content[0]) {
          responseText = anthropicMsg.content[0].text as string;
        }
        return res.json({ text: responseText });
      } catch (anthropicError) {
        console.error("Anthropic API error:", anthropicError);
        
        // Intentar con OpenAI si Anthropic falla y tenemos la clave
        if (process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY !== "mock-key") {
          try {
            // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            const userContent = errorMessage 
              ? `Por favor, corrige este código en ${language} que está generando el siguiente error: ${errorMessage}\n\n\`\`\`${language}\n${code}\n\`\`\``
              : `Por favor, revisa este código en ${language} y corrige cualquier problema o error que encuentres:\n\n\`\`\`${language}\n${code}\n\`\`\``;
              
            const completion = await openai.chat.completions.create({
              model: "gpt-4o",
              messages: [
                { role: "system", content: "Eres un asistente experto en programación que ayuda a corregir errores en el código. Proporciona soluciones claras y explica los problemas encontrados." },
                { role: "user", content: userContent }
              ],
              max_tokens: 1000,
            });
            
            const responseText = completion.choices[0].message.content || "No se pudo generar una corrección";
            
            return res.json({ text: responseText });
          } catch (openaiError) {
            console.error("OpenAI API error tras error de Anthropic:", openaiError);
            return res.json({
              text: "Lo siento, encontré errores al generar una corrección tanto con Anthropic como con OpenAI. Por favor, verifica tus API keys e intenta de nuevo."
            });
          }
        } else {
          return res.json({
            text: "Lo siento, encontré un error al generar una corrección con Anthropic. Por favor, verifica tu API key e intenta de nuevo."
          });
        }
      }
    } catch (error) {
      console.error("Error en AI fix:", error);
      res.status(500).json({ error: "Failed to generate code fix" });
    }
  });

  // Git operations API (simplified simulation)
  app.get("/api/git/status", (req, res) => {
    // Simulate git status
    res.json({
      branch: "main",
      ahead: 0,
      behind: 2,
      staged: [
        { path: "/src/app.js", status: "added" }
      ],
      unstaged: [
        { path: "/src/utils.js", status: "modified" }
      ]
    });
  });

  app.post("/api/git/stage", (req, res) => {
    const { path } = req.body;
    
    if (!path) {
      return res.status(400).json({ error: "Path is required" });
    }
    
    // Simulate staging a file
    res.json({ success: true });
  });

  app.post("/api/git/commit", (req, res) => {
    const { message } = req.body;
    
    if (!message) {
      return res.status(400).json({ error: "Commit message is required" });
    }
    
    // Simulate committing changes
    res.json({ success: true });
  });

  // Database APIs - Conversations
  app.get("/api/conversations", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      
      if (isNaN(userId)) {
        return res.status(400).json({ error: "UserId is required" });
      }
      
      const conversations = await storage.getConversations(userId);
      res.json(conversations);
    } catch (error) {
      console.error("Error getting conversations:", error);
      res.status(500).json({ error: "Failed to get conversations" });
    }
  });

  app.get("/api/conversations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid conversation ID" });
      }
      
      const conversation = await storage.getConversation(id);
      
      if (!conversation) {
        return res.status(404).json({ error: "Conversation not found" });
      }
      
      res.json(conversation);
    } catch (error) {
      console.error("Error getting conversation:", error);
      res.status(500).json({ error: "Failed to get conversation" });
    }
  });

  app.post("/api/conversations", async (req, res) => {
    try {
      // Validate request body
      const result = insertConversationSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ error: result.error.format() });
      }
      
      const conversation = await storage.createConversation(result.data);
      res.status(201).json(conversation);
    } catch (error) {
      console.error("Error creating conversation:", error);
      res.status(500).json({ error: "Failed to create conversation" });
    }
  });

  app.put("/api/conversations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { title } = req.body;
      
      if (isNaN(id) || !title) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      
      const conversation = await storage.updateConversation(id, title);
      
      if (!conversation) {
        return res.status(404).json({ error: "Conversation not found" });
      }
      
      res.json(conversation);
    } catch (error) {
      console.error("Error updating conversation:", error);
      res.status(500).json({ error: "Failed to update conversation" });
    }
  });

  app.delete("/api/conversations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid conversation ID" });
      }
      
      const success = await storage.deleteConversation(id);
      
      if (!success) {
        return res.status(404).json({ error: "Conversation not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting conversation:", error);
      res.status(500).json({ error: "Failed to delete conversation" });
    }
  });

  // Database APIs - Messages
  app.get("/api/messages/:conversationId", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      
      if (isNaN(conversationId)) {
        return res.status(400).json({ error: "Invalid conversation ID" });
      }
      
      const messages = await storage.getMessages(conversationId);
      res.json(messages);
    } catch (error) {
      console.error("Error getting messages:", error);
      res.status(500).json({ error: "Failed to get messages" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      // Validate request body
      const result = insertMessageSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ error: result.error.format() });
      }
      
      // Ensure the code and language fields are properly formatted for the database
      const messageData = {
        ...result.data,
        code: result.data.code || null,
        language: result.data.language || null
      };
      
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      res.status(500).json({ error: "Failed to create message" });
    }
  });

  // Database APIs - Files
  app.get("/api/uploaded-files/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ error: "Invalid user ID" });
      }
      
      const files = await storage.getUploadedFiles(userId);
      res.json(files);
    } catch (error) {
      console.error("Error getting uploaded files:", error);
      res.status(500).json({ error: "Failed to get uploaded files" });
    }
  });

  app.post("/api/uploaded-files", async (req, res) => {
    try {
      // Validate request body
      const result = insertUploadedFileSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ error: result.error.format() });
      }
      
      const file = await storage.createUploadedFile({
        ...result.data,
        conversationId: result.data.conversationId || null
      });
      res.status(201).json(file);
    } catch (error) {
      console.error("Error uploading file:", error);
      res.status(500).json({ error: "Failed to upload file" });
    }
  });

  // Database APIs - Terminal Commands
  app.get("/api/terminal-commands/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ error: "Invalid user ID" });
      }
      
      const commands = await storage.getTerminalCommands(userId);
      res.json(commands);
    } catch (error) {
      console.error("Error getting terminal commands:", error);
      res.status(500).json({ error: "Failed to get terminal commands" });
    }
  });

  app.post("/api/terminal-commands", async (req, res) => {
    try {
      // Validate request body
      const result = insertTerminalCommandSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ error: result.error.format() });
      }
      
      const command = await storage.createTerminalCommand({
        ...result.data,
        output: result.data.output || null
      });
      res.status(201).json(command);
    } catch (error) {
      console.error("Error saving terminal command:", error);
      res.status(500).json({ error: "Failed to save terminal command" });
    }
  });

  // Database APIs - AI Assistance History
  app.get("/api/ai-assistance/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ error: "Invalid user ID" });
      }
      
      const history = await storage.getAiAssistanceHistory(userId);
      res.json(history);
    } catch (error) {
      console.error("Error getting AI assistance history:", error);
      res.status(500).json({ error: "Failed to get AI assistance history" });
    }
  });

  app.post("/api/ai-assistance", async (req, res) => {
    try {
      // Validate request body
      const result = insertAiAssistanceSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ error: result.error.format() });
      }
      
      const assistance = await storage.createAiAssistance({
        ...result.data,
        codeContext: result.data.codeContext || null
      });
      res.status(201).json(assistance);
    } catch (error) {
      console.error("Error saving AI assistance:", error);
      res.status(500).json({ error: "Failed to save AI assistance" });
    }
  });

  const httpServer = createServer(app);
=======
import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertProjectSchema, 
  insertMessageSchema, 
  insertFileSchema,
  insertSettingsSchema,
  modelProviders,
  type ModelProvider,
  type InsertSettings
} from "@shared/schema";
import { 
  processAiRequest, 
  generateCode, 
  analyzeRequirements 
} from "./controllers/aiController";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // API Routes
  
  // Project routes
  app.get("/api/projects", async (req: Request, res: Response) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Error fetching projects" });
    }
  });

  app.get("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }
      
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Error fetching project" });
    }
  });

  app.post("/api/projects", async (req: Request, res: Response) => {
    try {
      const validationResult = insertProjectSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid project data", 
          errors: validationResult.error.format() 
        });
      }
      
      const project = await storage.createProject(validationResult.data);
      res.status(201).json(project);
    } catch (error) {
      res.status(500).json({ message: "Error creating project" });
    }
  });

  // Message routes
  app.get("/api/projects/:projectId/messages", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      if (isNaN(projectId)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }
      
      const messages = await storage.getMessages(projectId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Error fetching messages" });
    }
  });

  app.post("/api/messages", async (req: Request, res: Response) => {
    try {
      const validationResult = insertMessageSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid message data", 
          errors: validationResult.error.format() 
        });
      }
      
      const message = await storage.createMessage(validationResult.data);
      res.status(201).json(message);
    } catch (error) {
      res.status(500).json({ message: "Error creating message" });
    }
  });

  // Files routes
  app.get("/api/projects/:projectId/files", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      if (isNaN(projectId)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }
      
      const files = await storage.getFiles(projectId);
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Error fetching files" });
    }
  });

  app.post("/api/files", async (req: Request, res: Response) => {
    try {
      const validationResult = insertFileSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid file data", 
          errors: validationResult.error.format() 
        });
      }
      
      const file = await storage.createFile(validationResult.data);
      res.status(201).json(file);
    } catch (error) {
      res.status(500).json({ message: "Error creating file" });
    }
  });

  // Settings routes
  app.get("/api/settings", async (req: Request, res: Response) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Error fetching settings" });
    }
  });

  app.patch("/api/settings", async (req: Request, res: Response) => {
    try {
      const { preferred_model, api_keys } = req.body;
      
      // Validar el proveedor del modelo
      if (preferred_model !== undefined && !modelProviders.includes(preferred_model)) {
        return res.status(400).json({ 
          message: "Invalid model provider", 
          validProviders: modelProviders 
        });
      }
      
      // Validar objeto de claves API
      if (api_keys !== undefined && (typeof api_keys !== 'object' || api_keys === null)) {
        return res.status(400).json({ 
          message: "API keys must be an object" 
        });
      }
      
      // Preparar un objeto de actualización de configuración con tipado correcto
      const settingsUpdate: Partial<InsertSettings> = {};
      
      if (preferred_model !== undefined) {
        settingsUpdate.preferred_model = preferred_model as ModelProvider;
      }
      
      if (api_keys !== undefined) {
        // Obtener la configuración actual para mantener las claves que no se están actualizando
        const currentSettings = await storage.getSettings();
        
        // Combinar las claves API existentes con las nuevas
        const typedApiKeys: Record<ModelProvider, string> = {
          openai: typeof api_keys.openai === 'string' ? api_keys.openai : (currentSettings?.api_keys?.openai || ''),
          anthropic: typeof api_keys.anthropic === 'string' ? api_keys.anthropic : (currentSettings?.api_keys?.anthropic || ''),
          gemini: typeof api_keys.gemini === 'string' ? api_keys.gemini : (currentSettings?.api_keys?.gemini || '')
        };
        
        // Si las claves proporcionadas están vacías, intentar usar las del .env como respaldo
        if (typedApiKeys.openai === '' && process.env.OPENAI_API_KEY) {
          typedApiKeys.openai = process.env.OPENAI_API_KEY;
          console.log('Using OPENAI_API_KEY from environment variables');
        }
        
        if (typedApiKeys.anthropic === '' && process.env.ANTHROPIC_API_KEY) {
          typedApiKeys.anthropic = process.env.ANTHROPIC_API_KEY;
          console.log('Using ANTHROPIC_API_KEY from environment variables');
        }
        
        if (typedApiKeys.gemini === '' && process.env.GEMINI_API_KEY) {
          typedApiKeys.gemini = process.env.GEMINI_API_KEY;
          console.log('Using GEMINI_API_KEY from environment variables');
        }
        
        settingsUpdate.api_keys = typedApiKeys;
      }
      
      const settings = await storage.updateSettings(settingsUpdate);
      res.json(settings);
    } catch (error) {
      console.error('Error updating settings:', error);
      res.status(500).json({ message: "Error updating settings" });
    }
  });

  // AI processing routes
  app.post("/api/ai/process", async (req: Request, res: Response) => {
    try {
      const { prompt, model } = req.body;
      
      if (!prompt || typeof prompt !== "string") {
        return res.status(400).json({ error: "Invalid prompt format" });
      }
      
      if (!model || !modelProviders.includes(model)) {
        return res.status(400).json({ error: "Invalid model provider", validProviders: modelProviders });
      }
      
      // Set longer timeout for this request
      req.setTimeout(20000); // 20 seconds
      
      console.log(`Processing AI request with ${model} model`);
      const result = await processAiRequest(prompt, model);
      
      if (!result) {
        return res.status(500).json({ error: "AI model returned empty response" });
      }
      
      res.json(result);
    } catch (error: any) {
      console.error("Error in /api/ai/process:", error);
      res.status(500).json({ 
        error: "Error processing AI request", 
        details: error.message,
        provider: req.body.model
      });
    }
  });

  app.post("/api/ai/analyze", async (req: Request, res: Response) => {
    try {
      const { prompt, model } = req.body;
      
      if (!prompt || typeof prompt !== "string") {
        return res.status(400).json({ error: "Invalid prompt format" });
      }
      
      if (!model || !modelProviders.includes(model)) {
        return res.status(400).json({ error: "Invalid model provider", validProviders: modelProviders });
      }
      
      // Set longer timeout for this request
      req.setTimeout(20000); // 20 seconds
      
      console.log(`Analyzing requirements with ${model} model`);
      const result = await analyzeRequirements(prompt, model);
      
      if (!result || !result.analysisResult) {
        return res.status(500).json({ error: "AI analysis returned invalid response" });
      }
      
      res.json(result);
    } catch (error: any) {
      console.error("Error in /api/ai/analyze:", error);
      res.status(500).json({ 
        error: "Error analyzing requirements", 
        details: error.message,
        provider: req.body.model
      });
    }
  });

  app.post("/api/ai/generate", async (req: Request, res: Response) => {
    try {
      const { specs, model } = req.body;
      
      if (!specs || typeof specs !== "object") {
        return res.status(400).json({ error: "Invalid specifications format" });
      }
      
      if (!model || !modelProviders.includes(model)) {
        return res.status(400).json({ error: "Invalid model provider", validProviders: modelProviders });
      }
      
      // Set much longer timeout for code generation
      req.setTimeout(45000); // 45 seconds
      
      console.log(`Generating code with ${model} model`);
      const result = await generateCode(specs, model);
      
      if (!result || !result.generatedFiles || !Array.isArray(result.generatedFiles)) {
        return res.status(500).json({ error: "AI code generation returned invalid response" });
      }
      
      console.log(`Generated ${result.generatedFiles.length} files successfully`);
      res.json(result);
    } catch (error: any) {
      console.error("Error in /api/ai/generate:", error);
      res.status(500).json({ 
        error: "Error generating code", 
        details: error.message,
        provider: req.body.model
      });
    }
  });
>>>>>>> 132aeba36e2ea9de048066f0f5011c34e421d7d7

  return httpServer;
}
