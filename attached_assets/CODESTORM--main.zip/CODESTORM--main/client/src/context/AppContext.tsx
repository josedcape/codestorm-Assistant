import { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { ModelProvider } from '@shared/schema';

// Terminal line type
interface TerminalLine {
  text: string;
  type: 'command' | 'output' | 'success' | 'error' | 'code';
  language?: string;
  code?: string;
}

// Define message properties
interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
  analysis?: {
    frontend?: string;
    backend?: string;
    features?: string[];
    database?: string;
  };
}

// Project interface
interface Project {
  id: number;
  name: string;
  description: string;
  tech_stack: string[];
  files: {
    id: number;
    path: string;
    content: string;
    language: string;
  }[];
}

// Settings interface
interface Settings {
  id: number;
  preferred_model: ModelProvider;
  api_keys: Record<ModelProvider, string>;
}

// Context interface
interface AppContextType {
  messages: Message[];
  addMessage: (message: Message) => void;
  terminalLines: TerminalLine[];
  addTerminalLine: (line: TerminalLine) => void;
  clearTerminal: () => void;
  currentProject: Project | null;
  startNewProject: () => void;
  setCurrentProject: (project: Project) => void;
  selectedModel: ModelProvider;
  setSelectedModel: (model: ModelProvider) => void;
  isProcessing: boolean;
  setIsProcessing: (processing: boolean) => void;
  settings: Settings | null;
  refreshSettings: () => Promise<void>;
}

// Create context
const AppContext = createContext<AppContextType | undefined>(undefined);

// Context provider
export function AppProvider({ children }: { children: ReactNode }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>([]);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [selectedModel, setSelectedModel] = useState<ModelProvider>('openai');
  const [isProcessing, setIsProcessing] = useState(false);
  const [settings, setSettings] = useState<Settings | null>(null);
  const { toast } = useToast();
  
  // Fetch settings on initial load
  useEffect(() => {
    refreshSettings();
  }, []);
  
  const refreshSettings = async () => {
    try {
      const settings = await apiRequest('GET', '/api/settings');
      const data = await settings.json();
      setSettings(data);
      setSelectedModel(data.preferred_model);
    } catch (error) {
      console.error('Failed to fetch settings:', error);
    }
  };
  
  // Add a message to the chat
  const addMessage = (message: Message) => {
    setMessages(prev => [...prev, message]);
  };
  
  // Add a line to the terminal
  const addTerminalLine = (line: TerminalLine) => {
    setTerminalLines(prev => [...prev, line]);
  };
  
  // Clear the terminal
  const clearTerminal = () => {
    setTerminalLines([]);
  };
  
  // Start a new project
  const startNewProject = async () => {
    try {
      // Clear existing data
      setMessages([]);
      clearTerminal();
      
      // Create default welcome message
      addMessage({
        role: 'assistant',
        content: 'Bienvenido a un nuevo proyecto. ¿Qué tipo de aplicación deseas crear hoy?'
      });
      
      // Add initial terminal lines
      addTerminalLine({
        text: 'Inicializando nuevo entorno de proyecto...',
        type: 'command'
      });
      
      addTerminalLine({
        text: 'Entorno listo. Esperando especificaciones del proyecto.',
        type: 'success'
      });
      
      // Create a new project in the backend
      const result = await apiRequest('POST', '/api/projects', {
        name: 'Nuevo Proyecto',
        description: 'Proyecto en fase de especificación',
        tech_stack: []
      });
      
      const project = await result.json();
      setCurrentProject({
        ...project,
        files: []
      });
      
    } catch (error) {
      console.error('Error starting new project:', error);
      toast({
        title: 'Error',
        description: 'No se pudo iniciar un nuevo proyecto.',
        variant: 'destructive'
      });
    }
  };
  
  return (
    <AppContext.Provider
      value={{
        messages,
        addMessage,
        terminalLines,
        addTerminalLine,
        clearTerminal,
        currentProject,
        startNewProject,
        setCurrentProject,
        selectedModel,
        setSelectedModel,
        isProcessing,
        setIsProcessing,
        settings,
        refreshSettings,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

// Context hook
export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}
