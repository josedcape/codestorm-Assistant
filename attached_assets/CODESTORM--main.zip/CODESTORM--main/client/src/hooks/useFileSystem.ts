import { useState, useEffect } from 'react';
import { fileSystem } from '@/lib/fileSystem';
import { useToast } from '@/hooks/use-toast';

interface File {
  path: string;
  name: string;
}

interface Folder {
  path: string;
  name: string;
  expanded: boolean;
}

export default function useFileSystem() {
  const [files, setFiles] = useState<File[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [currentPath, setCurrentPath] = useState('/');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const fetchFiles = async (path = '/') => {
    setIsLoading(true);
    try {
      const { files: newFiles, folders: newFolders } = await fileSystem.listFiles(path);
      
      // Transform folder data structure to include expanded state
      const folderObjects: Folder[] = newFolders.map(folder => ({
        path: folder.path,
        name: folder.name,
        expanded: false
      }));
      
      setFiles(newFiles);
      setFolders(folderObjects);
      setCurrentPath(path);
    } catch (error) {
      console.error('Error fetching files:', error);
      toast({
        title: 'Error loading files',
        description: 'Could not load file list. Please try again.',
        variant: 'destructive'
      });
      
      // Use mock data for demonstration if the API fails
      setFiles([
        { path: '/src/app.js', name: 'app.js' },
        { path: '/src/utils.js', name: 'utils.js' },
        { path: '/src/api.js', name: 'api.js' },
        { path: '/package.json', name: 'package.json' },
        { path: '/README.md', name: 'README.md' },
        { path: '/.gitignore', name: '.gitignore' },
      ]);
      
      setFolders([
        { path: '/src', name: 'src', expanded: true },
        { path: '/public', name: 'public', expanded: false },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFiles(currentPath);
  }, []);

  const loadFileContent = async (path: string): Promise<string> => {
    try {
      return await fileSystem.readFile(path);
    } catch (error) {
      console.error('Error reading file:', error);
      toast({
        title: 'Error loading file',
        description: 'Could not load file content. Please try again.',
        variant: 'destructive'
      });
      
      // Return empty content as fallback
      return '';
    }
  };

  const saveFile = async (path: string, content: string): Promise<boolean> => {
    try {
      const success = await fileSystem.writeFile(path, content);
      if (success) {
        toast({
          title: 'File saved',
          description: `Successfully saved ${path.split('/').pop()}`,
        });
      }
      return success;
    } catch (error) {
      console.error('Error saving file:', error);
      toast({
        title: 'Error saving file',
        description: 'Could not save file. Please try again.',
        variant: 'destructive'
      });
      return false;
    }
  };

  const createFile = async (name: string, content: string = ''): Promise<boolean> => {
    try {
      const path = currentPath === '/' 
        ? `/${name}` 
        : `${currentPath}/${name}`;
        
      const success = await fileSystem.createFile(path, content);
      
      if (success) {
        toast({
          title: 'File created',
          description: `Successfully created ${name}`,
        });
        
        // Refresh file list
        await fetchFiles(currentPath);
      }
      
      return success;
    } catch (error) {
      console.error('Error creating file:', error);
      toast({
        title: 'Error creating file',
        description: 'Could not create file. Please try again.',
        variant: 'destructive'
      });
      return false;
    }
  };

  const createFolder = async (name: string): Promise<boolean> => {
    try {
      const path = currentPath === '/' 
        ? `/${name}` 
        : `${currentPath}/${name}`;
        
      const success = await fileSystem.createFolder(path);
      
      if (success) {
        toast({
          title: 'Folder created',
          description: `Successfully created folder ${name}`,
        });
        
        // Refresh file list
        await fetchFiles(currentPath);
      }
      
      return success;
    } catch (error) {
      console.error('Error creating folder:', error);
      toast({
        title: 'Error creating folder',
        description: 'Could not create folder. Please try again.',
        variant: 'destructive'
      });
      return false;
    }
  };

  const deleteFile = async (path: string): Promise<boolean> => {
    try {
      const success = await fileSystem.deleteFile(path);
      
      if (success) {
        toast({
          title: 'File deleted',
          description: `Successfully deleted ${path.split('/').pop()}`,
        });
        
        // Refresh file list
        await fetchFiles(currentPath);
      }
      
      return success;
    } catch (error) {
      console.error('Error deleting file:', error);
      toast({
        title: 'Error deleting file',
        description: 'Could not delete file. Please try again.',
        variant: 'destructive'
      });
      return false;
    }
  };

  const deleteFolder = async (path: string): Promise<boolean> => {
    try {
      const success = await fileSystem.deleteFolder(path);
      
      if (success) {
        toast({
          title: 'Folder deleted',
          description: `Successfully deleted folder ${path.split('/').pop()}`,
        });
        
        // Refresh file list
        await fetchFiles(currentPath);
      }
      
      return success;
    } catch (error) {
      console.error('Error deleting folder:', error);
      toast({
        title: 'Error deleting folder',
        description: 'Could not delete folder. Please try again.',
        variant: 'destructive'
      });
      return false;
    }
  };

  const refreshFiles = async (): Promise<void> => {
    await fetchFiles(currentPath);
  };

  const toggleFolderExpanded = (folderPath: string) => {
    setFolders(prev => 
      prev.map(folder => 
        folder.path === folderPath 
          ? { ...folder, expanded: !folder.expanded } 
          : folder
      )
    );
  };

  return {
    files,
    folders,
    currentPath,
    isLoading,
    loadFileContent,
    saveFile,
    createFile,
    createFolder,
    deleteFile,
    deleteFolder,
    refreshFiles,
    toggleFolderExpanded
  };
}
