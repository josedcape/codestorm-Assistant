import { useState } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface ExecutionResult {
  output: string;
  error?: string;
  exitCode: number;
}

export default function useCodeExecution() {
  const [isExecuting, setIsExecuting] = useState(false);
  const [lastResult, setLastResult] = useState<ExecutionResult | null>(null);
  const { toast } = useToast();

  const executeCode = async (
    code: string = '',
    language: string = 'javascript',
    filename: string = 'index.js'
  ): Promise<ExecutionResult> => {
    setIsExecuting(true);
    
    try {
      const response = await apiRequest('POST', '/api/execute', {
        code,
        language,
        filename
      });
      
      const result: ExecutionResult = await response.json();
      setLastResult(result);
      
      if (result.error) {
        toast({
          title: 'Execution Error',
          description: result.error.substring(0, 255), // Truncate long error messages
          variant: 'destructive'
        });
      } else {
        toast({
          title: 'Code executed successfully',
          description: result.exitCode === 0 ? 'Program completed normally' : `Program exited with code ${result.exitCode}`,
          variant: result.exitCode === 0 ? 'default' : 'destructive'
        });
      }
      
      return result;
    } catch (error) {
      console.error('Error executing code:', error);
      
      const errorResult: ExecutionResult = {
        output: '',
        error: error instanceof Error ? error.message : 'Unknown error during execution',
        exitCode: 1
      };
      
      setLastResult(errorResult);
      
      toast({
        title: 'Execution failed',
        description: 'Could not execute code. Check your connection and try again.',
        variant: 'destructive'
      });
      
      return errorResult;
    } finally {
      setIsExecuting(false);
    }
  };

  return {
    executeCode,
    isExecuting,
    lastResult
  };
}
