import { useState, useCallback } from 'react';
import { useAppContext } from '@/context/AppContext';

// Terminal line type from context
interface TerminalLine {
  text: string;
  type: 'command' | 'output' | 'success' | 'error' | 'code';
  language?: string;
  code?: string;
}

export function useTerminal() {
  const { terminalLines, addTerminalLine, clearTerminal } = useAppContext();
  
  // Execute a command in the terminal
  const executeCommand = useCallback((command: string) => {
    // Add the command to the terminal
    addTerminalLine({
      text: command,
      type: 'command'
    });
    
    // Process the command
    if (command.startsWith('mkdir') || command.startsWith('cd') || command.startsWith('touch')) {
      // File system operations
      addTerminalLine({
        text: `Executing: ${command}`,
        type: 'output'
      });
      
      setTimeout(() => {
        addTerminalLine({
          text: 'Completed',
          type: 'success'
        });
      }, 500);
    } else if (command.startsWith('npm') || command.startsWith('npx') || command.startsWith('yarn')) {
      // Package manager commands
      addTerminalLine({
        text: 'Installing packages. This might take a few minutes...',
        type: 'output'
      });
      
      // Simulate package installation
      setTimeout(() => {
        addTerminalLine({
          text: 'Packages installed successfully',
          type: 'success'
        });
      }, 1500);
    } else if (command.startsWith('git')) {
      // Git commands
      addTerminalLine({
        text: `Executing git command: ${command}`,
        type: 'output'
      });
      
      setTimeout(() => {
        addTerminalLine({
          text: 'Git operation completed',
          type: 'success'
        });
      }, 700);
    } else {
      // Unknown command
      addTerminalLine({
        text: `Command not recognized: ${command}`,
        type: 'error'
      });
    }
  }, [addTerminalLine]);
  
  // Add code to the terminal
  const addCode = useCallback((code: string, language: string = 'javascript', filename: string = '') => {
    if (filename) {
      addTerminalLine({
        text: `Creating file: ${filename}`,
        type: 'command'
      });
    }
    
    addTerminalLine({
      type: 'code',
      text: filename || 'Code snippet',
      code,
      language
    });
    
    if (filename) {
      addTerminalLine({
        text: `File created successfully`,
        type: 'success'
      });
    }
  }, [addTerminalLine]);
  
  // Execute multiple commands sequentially
  const executeCommands = useCallback((commands: string[], delayBetween: number = 1000) => {
    commands.forEach((command, index) => {
      setTimeout(() => {
        executeCommand(command);
      }, index * delayBetween);
    });
  }, [executeCommand]);
  
  return {
    terminalLines,
    executeCommand,
    executeCommands,
    addCode,
    clearTerminal
  };
}
