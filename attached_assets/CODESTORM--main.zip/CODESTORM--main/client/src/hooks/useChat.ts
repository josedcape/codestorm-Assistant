import { useCallback } from 'react';
import { useAppContext } from '@/context/AppContext';
import { apiRequest } from '@/lib/queryClient';
import { useTerminal } from './useTerminal';
import { useToast } from '@/hooks/use-toast';
import { ModelProvider } from '@shared/schema';

// Message interface to match context
interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
  analysis?: {
    frontend?: string;
    backend?: string;
    features?: string[];
    database?: string;
  };
}

export function useChat() {
  const { messages, addMessage, selectedModel, setIsProcessing, isProcessing, currentProject, setCurrentProject } = useAppContext();
  const { executeCommands, addCode } = useTerminal();
  const { toast } = useToast();
  
  // Process user message and get AI response
  const sendMessage = useCallback(async (content: string) => {
    if (isProcessing || !content) return;
    
    try {
      // Add user message to the chat
      addMessage({
        role: 'user',
        content
      });
      
      setIsProcessing(true);
      
      try {
        // Analyze the requirements
        const analysisResponse = await apiRequest('POST', '/api/ai/analyze', {
          prompt: content,
          model: selectedModel
        });
        
        if (!analysisResponse || !analysisResponse.ok) {
          throw new Error('Failed to analyze requirements');
        }
        
        const analysisData = await analysisResponse.json();
        const analysis = analysisData && analysisData.analysisResult ? analysisData.analysisResult : {
          frontend: null,
          backend: null,
          database: null,
          features: []
        };
        
        // Update the project with analysis information
        if (currentProject && analysis) {
          try {
            const techStack = [];
            if (analysis.frontend) techStack.push(analysis.frontend);
            if (analysis.backend) techStack.push(analysis.backend);
            if (analysis.database) techStack.push(analysis.database);
            
            // Update project in database
            const updateResult = await apiRequest('PATCH', `/api/projects/${currentProject.id}`, {
              name: currentProject.name,
              description: content,
              tech_stack: techStack
            });
            
            if (updateResult && updateResult.ok) {
              const updatedProject = await updateResult.json();
              setCurrentProject({
                ...updatedProject,
                files: currentProject.files
              });
            }
          } catch (error) {
            console.error("Error al actualizar el proyecto:", error);
          }
        }
        
        // Add assistant message with analysis
        addMessage({
          role: 'assistant',
          content: `He analizado tu solicitud y puedo ayudarte a crear este proyecto. Voy a configurar un entorno con ${analysis.frontend || 'frontend'} para el frontend${analysis.backend ? ` y ${analysis.backend} para el backend` : ''}.${analysis.database ? ` Usaremos ${analysis.database} como base de datos.` : ''}`,
          analysis: {
            frontend: analysis.frontend,
            backend: analysis.backend,
            features: analysis.features,
            database: analysis.database
          }
        });
        
        // Generate terminal commands based on analysis
        const commands = [];
        
        if (analysis.frontend || analysis.backend) {
          commands.push(`mkdir ${analysis.frontend || 'frontend'}_${analysis.backend || 'backend'}_project`);
          commands.push(`cd ${analysis.frontend || 'frontend'}_${analysis.backend || 'backend'}_project`);
          
          if (analysis.frontend === 'react') {
            commands.push('npx create-react-app client');
          } else if (analysis.frontend === 'vue') {
            commands.push('npm create vue@latest client');
          } else if (analysis.frontend === 'angular') {
            commands.push('ng new client');
          }
          
          if (analysis.backend === 'nodejs' || analysis.backend === 'express') {
            commands.push('mkdir server');
            commands.push('cd server');
            commands.push('npm init -y');
            commands.push('npm install express cors dotenv');
            if (analysis.database === 'mongodb') {
              commands.push('npm install mongoose');
            } else if (analysis.database === 'postgres') {
              commands.push('npm install pg');
            }
          }
        }
        
        // Execute the commands
        if (commands.length > 0) {
          executeCommands(commands, 800);
        }
        
        // Generate some code examples based on the request
        if (currentProject) {
          try {
            const codeResponse = await apiRequest('POST', '/api/ai/generate', {
              specs: analysis,
              model: selectedModel
            });
            
            if (codeResponse && codeResponse.ok) {
              try {
                const codeData = await codeResponse.json();
                
                // Create files in backend storage
                if (codeData && codeData.generatedFiles && codeData.generatedFiles.length > 0) {
                  try {
                    const filesResponse = await Promise.all(
                      codeData.generatedFiles.map((file: any) => 
                        apiRequest('POST', '/api/files', {
                          project_id: currentProject.id,
                          path: file.path || 'example.js',
                          content: file.content || '',
                          language: file.language || 'javascript'
                        })
                      )
                    );
                    
                    // Verificar respuestas válidas antes de procesar
                    const validResponses = filesResponse.filter(res => res && res.ok);
                    
                    if (validResponses.length > 0) {
                      // Update file list in current project
                      const newFiles = await Promise.all(validResponses.map(res => res.json()));
                      
                      setCurrentProject({
                        ...currentProject,
                        files: [...currentProject.files, ...newFiles]
                      });
                    }
                  } catch (error) {
                    console.error("Error al guardar archivos generados:", error);
                  }
                  
                  try {
                    // Show some of the generated code in the terminal
                    if (codeData.generatedFiles && codeData.generatedFiles.length > 0) {
                      const sampleFile = codeData.generatedFiles[0];
                      if (sampleFile && sampleFile.content) {
                        addCode(sampleFile.content, sampleFile.language || 'javascript', sampleFile.path || 'example.js');
                      }
                    }
                  } catch (error) {
                    console.error("Error al mostrar el código generado:", error);
                  }
                }
              } catch (error) {
                console.error("Error al procesar la respuesta de código:", error);
              }
            }
          } catch (error) {
            console.error("Error al generar código:", error);
          }
        }
      } catch (error) {
        console.error("Error en el proceso principal:", error);
        toast({
          title: 'Error',
          description: 'Hubo un problema procesando tu mensaje. Por favor, intenta de nuevo.',
          variant: 'destructive'
        });
        
        // Add error message
        addMessage({
          role: 'assistant',
          content: 'Lo siento, hubo un problema procesando tu solicitud. Por favor, verifica tu configuración de API o intenta de nuevo.'
        });
      }
    } catch (error) {
      console.error('Error general en sendMessage:', error);
    } finally {
      setIsProcessing(false);
    }
  }, [addMessage, selectedModel, isProcessing, setIsProcessing, executeCommands, addCode, currentProject, setCurrentProject, toast]);
  
  return {
    messages,
    sendMessage,
    isProcessing
  };
}
