import { apiRequest } from './queryClient';

// Interface for file operations
export interface FileSystemAPI {
  listFiles: (path?: string) => Promise<{
    files: { path: string; name: string }[];
    folders: { path: string; name: string }[];
  }>;
  readFile: (path: string) => Promise<string>;
  writeFile: (path: string, content: string) => Promise<boolean>;
  createFile: (path: string, content?: string) => Promise<boolean>;
  createFolder: (path: string) => Promise<boolean>;
  deleteFile: (path: string) => Promise<boolean>;
  deleteFolder: (path: string) => Promise<boolean>;
  renameFile: (oldPath: string, newPath: string) => Promise<boolean>;
  renameFolder: (oldPath: string, newPath: string) => Promise<boolean>;
}

export const fileSystem: FileSystemAPI = {
  async listFiles(path = '/') {
    const response = await apiRequest('GET', `/api/files?path=${encodeURIComponent(path)}`, undefined);
    return await response.json();
  },

  async readFile(path) {
    const response = await apiRequest('GET', `/api/files/${encodeURIComponent(path)}`, undefined);
    return await response.text();
  },

  async writeFile(path, content) {
    const response = await apiRequest('PUT', `/api/files/${encodeURIComponent(path)}`, { content });
    return response.ok;
  },

  async createFile(path, content = '') {
    const response = await apiRequest('POST', `/api/files`, { path, content });
    return response.ok;
  },

  async createFolder(path) {
    const response = await apiRequest('POST', `/api/folders`, { path });
    return response.ok;
  },

  async deleteFile(path) {
    const response = await apiRequest('DELETE', `/api/files/${encodeURIComponent(path)}`, undefined);
    return response.ok;
  },

  async deleteFolder(path) {
    const response = await apiRequest('DELETE', `/api/folders/${encodeURIComponent(path)}`, undefined);
    return response.ok;
  },

  async renameFile(oldPath, newPath) {
    const response = await apiRequest('PATCH', `/api/files/${encodeURIComponent(oldPath)}`, { newPath });
    return response.ok;
  },

  async renameFolder(oldPath, newPath) {
    const response = await apiRequest('PATCH', `/api/folders/${encodeURIComponent(oldPath)}`, { newPath });
    return response.ok;
  }
};
