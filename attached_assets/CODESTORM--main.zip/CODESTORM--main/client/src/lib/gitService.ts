import { apiRequest } from './queryClient';

export interface GitStatus {
  branch: string;
  ahead: number;
  behind: number;
  staged: { path: string; status: string }[];
  unstaged: { path: string; status: string }[];
}

export interface GitServiceAPI {
  getStatus: () => Promise<GitStatus>;
  stageFile: (path: string) => Promise<boolean>;
  unstageFile: (path: string) => Promise<boolean>;
  commit: (message: string) => Promise<boolean>;
  pull: () => Promise<boolean>;
  push: () => Promise<boolean>;
  checkout: (branch: string) => Promise<boolean>;
  createBranch: (name: string) => Promise<boolean>;
}

export const gitService: GitServiceAPI = {
  async getStatus() {
    const response = await apiRequest('GET', '/api/git/status', undefined);
    return await response.json();
  },
  
  async stageFile(path) {
    const response = await apiRequest('POST', '/api/git/stage', { path });
    return response.ok;
  },
  
  async unstageFile(path) {
    const response = await apiRequest('POST', '/api/git/unstage', { path });
    return response.ok;
  },
  
  async commit(message) {
    const response = await apiRequest('POST', '/api/git/commit', { message });
    return response.ok;
  },
  
  async pull() {
    const response = await apiRequest('POST', '/api/git/pull', undefined);
    return response.ok;
  },
  
  async push() {
    const response = await apiRequest('POST', '/api/git/push', undefined);
    return response.ok;
  },
  
  async checkout(branch) {
    const response = await apiRequest('POST', '/api/git/checkout', { branch });
    return response.ok;
  },
  
  async createBranch(name) {
    const response = await apiRequest('POST', '/api/git/branch', { name });
    return response.ok;
  }
};
