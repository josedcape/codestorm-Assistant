// Code templates and generation utilities for common project types

// React component template
export const reactComponentTemplate = (name: string, hasState: boolean = false) => `
import React${hasState ? ', { useState }' : ''} from 'react';

interface ${name}Props {
  title?: string;
}

export default function ${name}({ title = 'Default Title' }: ${name}Props) {
  ${hasState ? `const [count, setCount] = useState(0);
  
  const increment = () => {
    setCount(prev => prev + 1);
  };` : ''}

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">{title}</h1>
      ${hasState ? `<div>
        <p>Count: {count}</p>
        <button 
          onClick={increment}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Increment
        </button>
      </div>` : '<p>This is a simple component</p>'}
    </div>
  );
}
`;

// Express server template
export const expressServerTemplate = (withMongoDB: boolean = false) => `
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
${withMongoDB ? "import mongoose from 'mongoose';" : ''}

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(express.json());
app.use(cors());

// Routes
app.get('/api/hello', (req, res) => {
  res.json({ message: 'Hello from the server!' });
});

${withMongoDB ? `// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Could not connect to MongoDB', err));` : ''}

// Start server
app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});
`;

// MongoDB model template
export const mongoDBModelTemplate = (modelName: string, fields: Record<string, string>) => {
  const capitalizedName = modelName.charAt(0).toUpperCase() + modelName.slice(1);
  const fieldsStr = Object.entries(fields)
    .map(([key, type]) => `  ${key}: { type: ${type}, ${key === 'name' ? 'required: true' : ''} }`)
    .join(',\n');

  return `
import mongoose from 'mongoose';

const ${modelName}Schema = new mongoose.Schema({
${fieldsStr}
}, { timestamps: true });

export const ${capitalizedName} = mongoose.model('${capitalizedName}', ${modelName}Schema);
`;
};

// React hooks template
export const reactHookTemplate = (hookName: string) => `
import { useState, useEffect } from 'react';

export function ${hookName}(initialValue) {
  const [value, setValue] = useState(initialValue);
  
  // Example effect
  useEffect(() => {
    // Do something when value changes
    console.log('Value changed:', value);
    
    return () => {
      // Cleanup if needed
    };
  }, [value]);
  
  // Example methods
  const reset = () => setValue(initialValue);
  const update = (newValue) => setValue(newValue);
  
  return {
    value,
    setValue,
    reset,
    update
  };
}
`;

// Generate a package.json template
export const packageJsonTemplate = (projectName: string, hasFrontend: boolean, hasBackend: boolean) => {
  const dependencies: Record<string, string> = {};
  const devDependencies: Record<string, string> = {};
  
  if (hasBackend) {
    dependencies.express = "^4.18.2";
    dependencies.cors = "^2.8.5";
    dependencies.dotenv = "^16.3.1";
  }
  
  if (hasFrontend) {
    dependencies.react = "^18.2.0";
    dependencies["react-dom"] = "^18.2.0";
    devDependencies.vite = "^5.0.0";
    devDependencies["@vitejs/plugin-react"] = "^4.2.0";
  }
  
  return JSON.stringify(
    {
      name: projectName.toLowerCase().replace(/\s+/g, '-'),
      version: "0.1.0",
      private: true,
      scripts: {
        ...(hasFrontend ? { 
          dev: "vite",
          build: "vite build",
          preview: "vite preview"
        } : {}),
        ...(hasBackend ? {
          server: "node server/index.js",
          "server:dev": "nodemon server/index.js"
        } : {})
      },
      dependencies,
      devDependencies
    },
    null,
    2
  );
};
