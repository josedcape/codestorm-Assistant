// Templates for various project types

export interface ProjectTemplate {
  id: string;
  name: string;
  description: string;
  technologies: string[];
  fileStructure: {
    path: string;
    type: 'file' | 'directory';
    content?: string;
  }[];
}

export const templates: ProjectTemplate[] = [
  {
    id: 'react-express',
    name: 'React + Express',
    description: 'Aplicación web con frontend en React y backend en Express',
    technologies: ['react', 'express', 'nodejs'],
    fileStructure: [
      { path: 'client', type: 'directory' },
      { path: 'client/src', type: 'directory' },
      { path: 'client/src/App.jsx', type: 'file' },
      { path: 'client/src/index.jsx', type: 'file' },
      { path: 'client/public', type: 'directory' },
      { path: 'client/public/index.html', type: 'file' },
      { path: 'server', type: 'directory' },
      { path: 'server/index.js', type: 'file' },
      { path: 'server/routes', type: 'directory' },
      { path: 'server/models', type: 'directory' },
      { path: '.env', type: 'file' },
      { path: 'package.json', type: 'file' }
    ]
  },
  {
    id: 'mern-stack',
    name: 'MERN Stack',
    description: 'Aplicación web con MongoDB, Express, React y Node.js',
    technologies: ['react', 'express', 'nodejs', 'mongodb'],
    fileStructure: [
      { path: 'client', type: 'directory' },
      { path: 'client/src', type: 'directory' },
      { path: 'client/src/App.jsx', type: 'file' },
      { path: 'client/src/index.jsx', type: 'file' },
      { path: 'client/public', type: 'directory' },
      { path: 'client/public/index.html', type: 'file' },
      { path: 'server', type: 'directory' },
      { path: 'server/index.js', type: 'file' },
      { path: 'server/routes', type: 'directory' },
      { path: 'server/models', type: 'directory' },
      { path: 'server/models/User.js', type: 'file' },
      { path: '.env', type: 'file' },
      { path: 'package.json', type: 'file' }
    ]
  },
  {
    id: 'flask-react',
    name: 'Flask + React',
    description: 'Aplicación web con frontend en React y backend en Flask',
    technologies: ['react', 'flask', 'python'],
    fileStructure: [
      { path: 'client', type: 'directory' },
      { path: 'client/src', type: 'directory' },
      { path: 'client/src/App.jsx', type: 'file' },
      { path: 'client/src/index.jsx', type: 'file' },
      { path: 'client/public', type: 'directory' },
      { path: 'client/public/index.html', type: 'file' },
      { path: 'server', type: 'directory' },
      { path: 'server/app.py', type: 'file' },
      { path: 'server/models.py', type: 'file' },
      { path: 'server/routes.py', type: 'file' },
      { path: '.env', type: 'file' },
      { path: 'requirements.txt', type: 'file' }
    ]
  }
];

// Get a template by ID
export const getTemplateById = (id: string): ProjectTemplate | undefined => {
  return templates.find(template => template.id === id);
};

// Get a list of templates filtered by technology
export const getTemplatesByTechnology = (technology: string): ProjectTemplate[] => {
  return templates.filter(template => 
    template.technologies.some(tech => tech.toLowerCase() === technology.toLowerCase())
  );
};
