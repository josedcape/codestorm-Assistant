import { editor } from 'monaco-editor';

// Define the editor theme
export const defineMonacoTheme = (monaco: any) => {
  monaco.editor.defineTheme('codestorm-dark', {
    base: 'vs-dark',
    inherit: true,
    rules: [
      { token: 'comment', foreground: '6a9955' },
      { token: 'string', foreground: 'ce9178' },
      { token: 'keyword', foreground: '569cd6' },
      { token: 'function', foreground: 'dcdcaa' },
      { token: 'variable', foreground: '9cdcfe' },
      { token: 'type', foreground: '4ec9b0' },
      { token: 'number', foreground: 'b5cea8' },
      { token: 'operator', foreground: 'd4d4d4' },
    ],
    colors: {
      'editor.background': '#1e1e1e',
      'editor.foreground': '#cccccc',
      'editorCursor.foreground': '#ffffff',
      'editor.lineHighlightBackground': '#282828',
      'editorLineNumber.foreground': '#858585',
      'editor.selectionBackground': '#264f7860',
      'editor.inactiveSelectionBackground': '#3a3d41',
      'editorIndentGuide.background': '#404040',
    },
  });
};

// Configure editor options
export const configureEditorOptions = (editor: editor.IStandaloneCodeEditor): void => {
  editor.updateOptions({
    fontFamily: "'Roboto Mono', 'Consolas', 'Courier New', 'monospace'",
    fontSize: 14,
    lineNumbers: 'on',
    lineHeight: 21,
    minimap: { enabled: false },
    scrollBeyondLastLine: false,
    automaticLayout: true,
    tabSize: 2,
    wordWrap: 'on',
    theme: 'codestorm-dark',
  });
};

// Add custom keyboard shortcuts
export const configureKeyBindings = (editor: editor.IStandaloneCodeEditor, monaco: any): void => {
  editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => {
    // Save action
    const model = editor.getModel();
    if (model) {
      const content = model.getValue();
      console.log('Saving content:', content);
      // Here you would save the file content
    }
  });

  editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyF, () => {
    // Find action
    editor.getAction('actions.find').run();
  });

  editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyF, () => {
    // Find and replace action
    editor.getAction('actions.findWithSelection').run();
  });
};

// Helper function to get language ID from file extension
export const getLanguageFromFilename = (filename: string): string => {
  const extension = filename.split('.').pop()?.toLowerCase() || '';
  
  const extensionMap: Record<string, string> = {
    'js': 'javascript',
    'ts': 'typescript',
    'jsx': 'javascript',
    'tsx': 'typescript',
    'html': 'html',
    'css': 'css',
    'json': 'json',
    'md': 'markdown',
    'py': 'python',
    'java': 'java',
    'c': 'c',
    'cpp': 'cpp',
    'cs': 'csharp',
    'go': 'go',
    'rs': 'rust',
    'php': 'php',
    'rb': 'ruby',
    'sh': 'shell',
  };
  
  return extensionMap[extension] || 'plaintext';
};
