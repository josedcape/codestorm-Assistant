import { useState } from 'react';
import { apiRequest } from './queryClient';

export interface AIServiceResponse {
  text: string;
}

export const useAIService = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getApiKey = (model: string): string | null => {
    // Obtener la clave API correcta según el modelo
    if (model.includes('gpt') || model === 'gpt-4o') {
      return localStorage.getItem('openai_api_key');
    } else if (model.includes('claude')) {
      return localStorage.getItem('anthropic_api_key');
    } else if (model.includes('gemini')) {
      return localStorage.getItem('google_api_key');
    } else if (model.includes('qwen')) {
      return localStorage.getItem('alibaba_api_key');
    }
    return null;
  };

  const generateResponse = async (
    prompt: string, 
    context: string = '', 
    codeContext: string = '',
    model: string = 'gpt-4o'
  ): Promise<string> => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Obtener la clave API correspondiente al modelo
      const apiKey = getApiKey(model);
      
      const response = await apiRequest('POST', '/api/ai/generate', {
        prompt,
        context,
        codeContext,
        model,
        apiKey
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Error en la comunicación con la API');
      }
      
      const data: AIServiceResponse = await response.json();
      return data.text;
    } catch (error) {
      console.error('Error generating AI response:', error);
      const errorMessage = error instanceof Error ? error.message : 'Error desconocido';
      setError(errorMessage);
      return `Lo siento, encontré un error: ${errorMessage}. Por favor verifica tu clave API y conexión.`;
    } finally {
      setIsLoading(false);
    }
  };

  const generateCodeSuggestion = async (
    code: string,
    language: string,
    prompt: string
  ): Promise<string> => {
    try {
      setIsLoading(true);
      
      const response = await apiRequest('POST', '/api/ai/code', {
        code,
        language,
        prompt
      });
      
      const data: AIServiceResponse = await response.json();
      return data.text;
    } catch (error) {
      console.error('Error generating code suggestion:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const explainCode = async (
    code: string,
    language: string
  ): Promise<string> => {
    try {
      setIsLoading(true);
      
      const response = await apiRequest('POST', '/api/ai/explain', {
        code,
        language
      });
      
      const data: AIServiceResponse = await response.json();
      return data.text;
    } catch (error) {
      console.error('Error explaining code:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const fixBugs = async (
    code: string,
    language: string,
    errorMessage?: string
  ): Promise<string> => {
    try {
      setIsLoading(true);
      
      const response = await apiRequest('POST', '/api/ai/fix', {
        code,
        language,
        errorMessage
      });
      
      const data: AIServiceResponse = await response.json();
      return data.text;
    } catch (error) {
      console.error('Error fixing bugs:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    generateResponse,
    generateCodeSuggestion,
    explainCode,
    fixBugs,
    isLoading
  };
};
