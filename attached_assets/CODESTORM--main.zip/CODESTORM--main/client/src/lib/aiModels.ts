import { ModelProvider } from '@shared/schema';

// Model descriptions
export const modelDescriptions = {
  openai: {
    name: 'GPT-4',
    description: 'Mayor precisión, código avanzado',
    apiKeyFormat: 'sk-...',
    advantages: [
      'Excelente precisión en la generación de código',
      'Comprensión avanzada del contexto',
      'Amplio conocimiento de tecnologías y frameworks'
    ]
  },
  anthropic: {
    name: 'Claude 3',
    description: 'Explicaciones detalladas',
    apiKeyFormat: 'sk-ant-...',
    advantages: [
      'Explicaciones detalladas del código generado',
      'Buena comprensión de requisitos complejos',
      'Respuestas bien estructuradas'
    ]
  },
  gemini: {
    name: 'Gemini Pro',
    description: 'Balanceado para código',
    apiKeyFormat: 'AIza...',
    advantages: [
      'Buen equilibrio entre explicaciones y código',
      'Opciones de personalización',
      'Optimizado para proyectos de tamaño mediano'
    ]
  }
};

// Model capabilities
export const modelCapabilities = {
  openai: [
    'Generación de código completo',
    'Análisis detallado de requisitos',
    'Recomendaciones de arquitectura',
    'Resolución de problemas de código',
    'Optimización de código existente'
  ],
  anthropic: [
    'Documentación exhaustiva',
    'Explicaciones paso a paso',
    'Generación de código con comentarios',
    'Análisis de seguridad básico',
    'Sugerencias de patrones de diseño'
  ],
  gemini: [
    'Generación de código eficiente',
    'Detección de errores comunes',
    'Sugerencias de mejores prácticas',
    'Explicaciones concisas',
    'Implementaciones alternativas'
  ]
};

// Get model full name
export const getModelFullName = (modelId: ModelProvider): string => {
  return modelDescriptions[modelId]?.name || modelId;
};

// Check if API key is valid format (basic validation)
export const isApiKeyValid = (apiKey: string, modelId: ModelProvider): boolean => {
  if (!apiKey) return false;
  
  switch (modelId) {
    case 'openai':
      return apiKey.startsWith('sk-') && apiKey.length > 20;
    case 'anthropic':
      return apiKey.startsWith('sk-ant-') && apiKey.length > 20;
    case 'gemini':
      return apiKey.startsWith('AIza') && apiKey.length > 20;
    default:
      return apiKey.length > 10;
  }
};
