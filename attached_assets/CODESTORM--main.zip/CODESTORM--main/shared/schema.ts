<<<<<<< HEAD
import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  preferences: json("preferences"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  preferences: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// File system schemas
export interface File {
  path: string;
  name: string;
}

export interface Folder {
  path: string;
  name: string;
}

// Project schema
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
  description: true,
  userId: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// Code file schema
export const codeFiles = pgTable("code_files", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  path: text("path").notNull(),
  content: text("content"),
  projectId: integer("project_id").notNull(),
  language: text("language"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertCodeFileSchema = createInsertSchema(codeFiles).pick({
  name: true,
  path: true,
  content: true,
  projectId: true,
  language: true,
});

export type InsertCodeFile = z.infer<typeof insertCodeFileSchema>;
export type CodeFile = typeof codeFiles.$inferSelect;

// AI assistance schema
export const aiAssistance = pgTable("ai_assistance", {
  id: serial("id").primaryKey(),
  prompt: text("prompt").notNull(),
  response: text("response").notNull(),
  codeContext: text("code_context"),
  userId: integer("user_id").notNull(),
  modelUsed: text("model_used").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAiAssistanceSchema = createInsertSchema(aiAssistance).pick({
  prompt: true,
  response: true,
  codeContext: true,
  userId: true,
  modelUsed: true,
});

export type InsertAiAssistance = z.infer<typeof insertAiAssistanceSchema>;
export type AiAssistance = typeof aiAssistance.$inferSelect;

// Conversations schema (for chat history)
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  title: true,
  userId: true,
});

export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;

// Messages schema (for conversation messages)
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull(),
  role: text("role").notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  code: text("code"),
  language: text("language"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  conversationId: true,
  role: true,
  content: true,
  code: true,
  language: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Uploaded files schema
export const uploadedFiles = pgTable("uploaded_files", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  content: text("content").notNull(),
  userId: integer("user_id").notNull(),
  conversationId: integer("conversation_id"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertUploadedFileSchema = createInsertSchema(uploadedFiles).pick({
  filename: true,
  content: true,
  userId: true,
  conversationId: true,
});

export type InsertUploadedFile = z.infer<typeof insertUploadedFileSchema>;
export type UploadedFile = typeof uploadedFiles.$inferSelect;

// Terminal commands history
export const terminalCommands = pgTable("terminal_commands", {
  id: serial("id").primaryKey(),
  command: text("command").notNull(),
  output: text("output"),
  userId: integer("user_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertTerminalCommandSchema = createInsertSchema(terminalCommands).pick({
  command: true,
  output: true,
  userId: true,
});

export type InsertTerminalCommand = z.infer<typeof insertTerminalCommandSchema>;
export type TerminalCommand = typeof terminalCommands.$inferSelect;
=======
import { pgTable, text, serial, integer, json, timestamp } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define the AI model types
export const modelProviders = ["openai", "anthropic", "gemini"] as const;
export type ModelProvider = typeof modelProviders[number];

// Projects table - stores metadata about generated projects
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  tech_stack: text("tech_stack").array().notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

// Chat messages table - stores conversation history 
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  project_id: integer("project_id").references(() => projects.id),
  role: text("role", { enum: ["user", "assistant", "system"] }).notNull(),
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Generated files table - tracks files created for a project
export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  project_id: integer("project_id").references(() => projects.id).notNull(),
  path: text("path").notNull(),
  content: text("content").notNull(),
  language: text("language").notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

// Settings table - stores user preferences and API keys
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  preferred_model: text("preferred_model", { enum: [...modelProviders] }).default("openai"),
  api_keys: json("api_keys").$type<Record<ModelProvider, string>>(),
});

// Define relations between tables
export const projectsRelations = relations(projects, ({ many }) => {
  return {
    messages: many(messages),
    files: many(files),
  };
});

export const messagesRelations = relations(messages, ({ one }) => {
  return {
    project: one(projects, {
      fields: [messages.project_id],
      references: [projects.id],
    }),
  };
});

export const filesRelations = relations(files, ({ one }) => {
  return {
    project: one(projects, {
      fields: [files.project_id],
      references: [projects.id],
    }),
  };
});

// Create insert schemas
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, created_at: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, timestamp: true });
export const insertFileSchema = createInsertSchema(files).omit({ id: true, created_at: true });
export const insertSettingsSchema = createInsertSchema(settings).omit({ id: true });

// Create types
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertFile = z.infer<typeof insertFileSchema>;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;

export type Project = typeof projects.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type File = typeof files.$inferSelect;
export type Settings = typeof settings.$inferSelect;
>>>>>>> 132aeba36e2ea9de048066f0f5011c34e421d7d7
