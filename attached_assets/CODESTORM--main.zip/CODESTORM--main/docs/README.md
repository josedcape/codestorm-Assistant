# CODESTORM AI - Documentación

## Descripción General

CODESTORM AI es un agente autónomo de desarrollo especializado en la generación de código a partir de lenguaje natural. Esta potente herramienta permite convertir instrucciones escritas en lenguaje natural a código funcional, optimizando y acelerando el proceso de desarrollo de software.

La aplicación integra múltiples modelos de inteligencia artificial (OpenAI, Anthropic, Gemini) con un sistema avanzado de respaldo (fallback) que garantiza alta disponibilidad y consistencia en las respuestas.

## Arquitectura del Sistema

CODESTORM AI está construido con una arquitectura moderna de cliente-servidor:

- **Frontend**: Interfaz de usuario desarrollada con React y Tailwind CSS
- **Backend**: Servidor Express.js que maneja las solicitudes a las APIs de IA
- **Almacenamiento**: Sistema en memoria para el desarrollo rápido de prototipos
- **Proveedores de IA**: Conexión con múltiples APIs (OpenAI, Anthropic, Gemini)

## Requisitos del Sistema

- Node.js 18.x o superior
- Claves API para al menos uno de los siguientes proveedores:
  - OpenAI (OPENAI_API_KEY)
  - Anthropic (ANTHROPIC_API_KEY)
  - Google Gemini (GEMINI_API_KEY)

## Instalación

1. Clonar el repositorio
2. Ejecutar `npm install` para instalar todas las dependencias
3. Configurar las variables de entorno en un archivo `.env`:
   ```
   OPENAI_API_KEY=tu_clave_de_openai
   ANTHROPIC_API_KEY=tu_clave_de_anthropic
   GEMINI_API_KEY=tu_clave_de_gemini
   ```
4. Iniciar la aplicación con `npm run dev`

## Uso de la Aplicación

### 1. Interacción básica con la IA

CODESTORM AI permite enviar prompts de texto para obtener respuestas generadas por los modelos de IA. El sistema seleccionará automáticamente el mejor modelo disponible según la configuración y estado de las APIs.

**Endpoint**: `POST /api/ai/process`

**Cuerpo de la solicitud**:
```json
{
  "prompt": "¿Cuáles son las mejores prácticas para desarrollo web?",
  "model": "openai" // "openai", "anthropic" o "gemini"
}
```

**Respuesta**: Texto generado por el modelo de IA seleccionado.

### 2. Análisis de Requisitos

Esta función analiza descripciones en lenguaje natural de proyectos de software y extrae especificaciones técnicas estructuradas.

**Endpoint**: `POST /api/ai/analyze`

**Cuerpo de la solicitud**:
```json
{
  "prompt": "Crea una aplicación web para gestionar tareas con autenticación de usuarios",
  "model": "anthropic" // "openai", "anthropic" o "gemini"
}
```

**Respuesta**:
```json
{
  "analysisResult": {
    "frontend": "React",
    "backend": "Express",
    "database": "MongoDB",
    "features": ["gestión de tareas", "autenticación de usuarios"],
    "authentication": true,
    "deployment": null,
    "complexity": "medium"
  },
  "rawResponse": "..." // Respuesta completa del modelo
}
```

### 3. Generación de Código

La función principal de CODESTORM AI es generar código a partir de especificaciones técnicas. Puede crear archivos de código para diversos frameworks y lenguajes.

**Endpoint**: `POST /api/ai/generate`

**Cuerpo de la solicitud**:
```json
{
  "specs": {
    "frontend": "React",
    "backend": "Express",
    "database": "MongoDB",
    "features": ["login", "task management"]
  },
  "model": "openai" // "openai", "anthropic" o "gemini"
}
```

**Respuesta**:
```json
{
  "generatedFiles": [
    {
      "path": "src/App.js",
      "content": "// Código del archivo",
      "language": "javascript"
    },
    {
      "path": "src/components/Login.js",
      "content": "// Código del componente",
      "language": "javascript"
    }
    // Más archivos generados
  ],
  "instructions": "Instrucciones para configurar y ejecutar el proyecto",
  "rawResponse": "..." // Respuesta completa del modelo
}
```

## Características Avanzadas

### Sistema de Respaldo (Fallback)

CODESTORM AI implementa un sofisticado sistema de respaldo que garantiza alta disponibilidad:

- Si un modelo falla o agota el tiempo de espera, el sistema automáticamente intenta con un proveedor alternativo
- Configuración de tiempo máximo de espera para prevenir bloqueos
- Reintentos automáticos con modelos alternativos
- Simplificación automática de solicitudes complejas cuando se utiliza un proveedor alternativo

### Optimización de Prompts

El sistema optimiza las instrucciones enviadas a los modelos de IA para:

- Reducir el consumo de tokens
- Mejorar la consistencia de las respuestas
- Obtener formatos JSON estructurados
- Minimizar el tiempo de respuesta

### Validación de Respuestas

CODESTORM AI incluye validación robusta de las respuestas:

- Verificación de estructura JSON
- Comprobación de campos requeridos
- Formateo coherente de valores (arrays, booleanos, etc.)
- Manejo de errores detallado con mensajes informativos

## Configuración y Personalización

### Variables de Entorno

- `OPENAI_API_KEY`: Clave API para OpenAI
- `ANTHROPIC_API_KEY`: Clave API para Anthropic
- `GEMINI_API_KEY`: Clave API para Google Gemini

### Tiempo de Espera

Los tiempos de espera están configurados para diferentes operaciones:

- Procesamiento básico: 10 segundos
- Análisis de requisitos: 8 segundos
- Generación de código: 15 segundos
- Tiempo de espera HTTP: 45 segundos para generación de código

Estos valores pueden ajustarse en los archivos:
- `server/controllers/aiController.ts`
- `server/routes.ts`

## Solución de Problemas

### Error: "AI request timed out"

**Causa**: El modelo de IA tardó demasiado en responder.
**Solución**: El sistema intentará automáticamente con otro proveedor. Si persiste, considera:
1. Simplificar la solicitud
2. Aumentar el tiempo de espera en la configuración
3. Verificar la conectividad con los proveedores de IA

### Error: "Failed to parse AI response"

**Causa**: La respuesta del modelo no está en el formato JSON esperado.
**Solución**: 
1. El sistema intentará con otro proveedor
2. Revisar los logs para identificar el formato incorrecto
3. Ajustar las instrucciones del prompt para mejorar el formato

### Error: "API key not found"

**Causa**: Falta la clave API necesaria en las variables de entorno.
**Solución**:
1. Verificar que las claves API estén correctamente configuradas en el archivo `.env`
2. Asegurarse de que al menos una clave API esté disponible

## Extensión del Sistema

CODESTORM AI está diseñado para ser fácilmente extensible:

1. **Añadir nuevos modelos**: Crear un nuevo archivo en `server/ai/` e implementar las funciones necesarias
2. **Personalizar análisis**: Modificar el prompt en `analyzeRequirements()` para extraer información adicional
3. **Mejorar generación de código**: Ajustar el prompt y la estructura en `generateCode()`
4. **Integrar con bases de datos**: Reemplazar el almacenamiento en memoria con una base de datos persistente

## Ejemplos de Uso

### Generar una Aplicación Web Simple

```javascript
// Solicitud
const response = await fetch('/api/ai/generate', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    specs: {
      frontend: "React",
      backend: "Express",
      features: ["contact form", "about page"]
    },
    model: "openai"
  })
});

// Procesar archivos generados
const result = await response.json();
console.log(`Archivos generados: ${result.generatedFiles.length}`);
```

### Analizar una Descripción de Proyecto

```javascript
// Solicitud
const response = await fetch('/api/ai/analyze', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    prompt: "Necesito una aplicación móvil para seguimiento de fitness con gráficos de progreso",
    model: "anthropic"
  })
});

// Utilizar el análisis
const result = await response.json();
console.log(`Tecnologías recomendadas: ${result.analysisResult.frontend}, ${result.analysisResult.backend}`);
```

## Consideraciones de Seguridad

- No exponga sus claves API en código cliente
- Valide todas las entradas de usuario antes de enviarlas a los modelos de IA
- Considere implementar limitación de velocidad para prevenir abuso
- Revise el código generado antes de ejecutarlo en entornos de producción

## Recursos y Enlaces

- [Documentación de OpenAI](https://platform.openai.com/docs)
- [Documentación de Anthropic](https://docs.anthropic.com/claude/reference)
- [Documentación de Google Gemini](https://ai.google.dev/gemini-api)
- [Guía de Express.js](https://expressjs.com/es/guide/routing.html)
- [Documentación de React](https://reactjs.org/docs/getting-started.html)

## Soporte

Para obtener ayuda con CODESTORM AI, consulte:
- La documentación en este README
- Los comentarios en el código fuente
- Los mensajes de error detallados proporcionados por la API

---

Desarrollado con ♥ por el equipo CODESTORM AI